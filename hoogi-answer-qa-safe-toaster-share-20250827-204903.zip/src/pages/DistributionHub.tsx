import React, { useEffect, useMemo, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { supabase } from '../integrations/supabase/client';
import { buildPublicUrl, buildEditUrl } from '../lib/publicUrl';
import ShareDialog from '../components/ShareDialog';
import { toast, announce } from '@/components/ui/toaster';

// טיפוסים
export type QMin = { id: string; token: string; title: string };
export type Lang = 'he' | 'en';

export default function DistributionHub() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();

  // URL param (אופציונלי)
  const urlToken = searchParams.get('token') ?? undefined;

  // מצב נתונים
  const [list, setList] = useState<QMin[]>([]);
  const [current, setCurrent] = useState<QMin | null>(null);
  const [lang, setLang] = useState<Lang>('he');
  const [ref, setRef] = useState<string>('landing');

  // טעינה/שגיאות קטנות
  const [loading, setLoading] = useState<boolean>(false);
  const [inlineMsg, setInlineMsg] = useState<string | null>(null);

  // דיאלוג בחירת מודל אימייל
  const [emailDialogOpen, setEmailDialogOpen] = useState<boolean>(false);
  // דיאלוג שיתוף
  const [shareOpen, setShareOpen] = useState<boolean>(false);

  // טעינת רשימה מה־view
  useEffect(() => {
    let ignore = false;
    (async () => {
      setLoading(true);
      setInlineMsg(null);
      try {
        const { data, error } = await supabase
          .from('questionnaires_min')
          .select('id,token,title')
          .order('title', { ascending: true });
        if (error) throw error;
        const listData = (data ?? []) as QMin[];
        if (ignore) return;
        setList(listData);

        // בחירת current לפי token מה-URL, או ברירת מחדל לפריט הראשון
        if (listData.length === 0) {
          setCurrent(null);
        } else {
          const byToken = urlToken
            ? listData.find((x) => x.token === urlToken) ?? null
            : null;
          setCurrent(byToken ?? listData[0]);

          if (urlToken && !byToken) {
            // אם הטוקן לא נמצא ברשימה, ננסה שליפה נקודתית כדי להבדיל בין "לא נמצא" ל-406/null
            const { data: single, error: singleErr } = await supabase
              .from('questionnaires_min')
              .select('id,token,title')
              .eq('token', urlToken)
              .maybeSingle();
            if (!ignore) {
              if (singleErr) {
                setInlineMsg(singleErr.message || 'שגיאה בטעינה');
              } else if (!single) {
                setInlineMsg('שאלון לא נמצא');
              }
            }
          }
        }
      } catch (e: any) {
        if (!ignore) setInlineMsg(e?.message ?? 'שגיאה בטעינת השאלונים');
      } finally {
        if (!ignore) setLoading(false);
      }
    })();
    return () => {
      ignore = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // קישור ציבורי (מוחלט)
  const publicUrl = useMemo(() => {
    if (!current) return '';
    const origin = typeof window !== 'undefined' ? window.location.origin : '';
    const built = buildPublicUrl(origin, current.token, lang, ref);
    announce('הקישור עודכן');
    return built;
  }, [current, lang, ref]);

  // תבנית שיתוף אחידה
  const shareText = useMemo(() => {
    return `${current?.title ?? 'שאלון'} – נשמח לפרט, מלא/י: ${publicUrl}`;
  }, [current?.title, publicUrl]);

  // פעולות
  const handleCopy = async () => {
    if (!publicUrl) return;
    try {
      await navigator.clipboard.writeText(publicUrl);
      toast.success('קישור הועתק');
    } catch {
      toast.error('לא ניתן להעתיק', { description: 'נסי ידנית' });
    }
  };

  const handleWhatsApp = async () => {
    if (!current || !publicUrl) return;
    const href = `https://wa.me/?text=${encodeURIComponent(shareText)}`;
    const popup = window.open(href, '_blank', 'noopener,noreferrer');
    if (!popup || popup.closed) {
      try { await navigator.clipboard.writeText(shareText); toast.success('קישור הועתק'); } catch { toast.error('לא ניתן להעתיק', { description: 'נסי ידנית' }); }
    }
  };

  // email providers
  type EmailProvider = 'default' | 'gmail' | 'outlook';
  const openEmailProvider = (provider: EmailProvider) => {
    if (!current || !publicUrl) return;
    const subject = encodeURIComponent(current.title || 'Questionnaire');
    const body = encodeURIComponent(shareText);
    if (provider === 'gmail') {
      const url = `https://mail.google.com/mail/?view=cm&fs=1&su=${subject}&body=${body}`;
      window.open(url, '_blank', 'noopener,noreferrer');
      return;
    }
    if (provider === 'outlook') {
      const url = `https://outlook.live.com/mail/0/deeplink/compose?subject=${subject}&body=${body}`;
      window.open(url, '_blank', 'noopener,noreferrer');
      return;
    }
    const href = `mailto:?subject=${subject}&body=${body}`;
    window.location.href = href;
  };

  const handleEmail = () => {
    setEmailDialogOpen(true);
  };

  const handlePreview = () => {
    if (!publicUrl) return;
    window.open(publicUrl, '_blank', 'noopener,noreferrer');
  };

  const handleEdit = () => {
    if (!current) return;
    navigate(buildEditUrl(current.id));
  };

  // החלפת שאלון מהקומבו – מעדכן URL param ושומר מצב, ומוודא קיום token דרך RPC אם חסר
  const handleSelect = async (id: string) => {
    const next = list.find((x) => x.id === id) ?? null;
    if (!next) {
      setCurrent(null);
      const usp = new URLSearchParams(searchParams);
      usp.delete('token');
      setSearchParams(usp, { replace: true });
      return;
    }

    let ensuredToken = next.token;
    if (!ensuredToken) {
      try {
        const { data, error } = await supabase.rpc('ensure_questionnaire_token', { qid: id });
        if (!error && data) {
          ensuredToken = String(data);
        }
      } catch {}
    }

    const updated: QMin = { id: next.id, title: next.title, token: ensuredToken } as QMin;
    setCurrent(updated);

    const usp = new URLSearchParams(searchParams);
    if (ensuredToken) usp.set('token', ensuredToken); else usp.delete('token');
    setSearchParams(usp, { replace: true });
  };

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      <div className="container mx-auto p-4 sm:p-6 max-w-3xl">
        <div className="mb-6">
          <h1 className="text-3xl font-bold">הפצה</h1>
          <p className="text-muted-foreground">ניהול קישורי הפצה, תצוגה מקדימה ושיתוף מהיר – במקום אחד.</p>
        </div>

        <div className="bg-card border border-border rounded-lg p-4 space-y-4">
          {/* בחירת שאלון */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs text-muted-foreground mb-1" htmlFor="qsel">שאלון</label>
              <select
                id="qsel"
                aria-label="בחירת שאלון"
                className="w-full px-2 py-2 text-sm bg-background border border-border rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                value={current?.id ?? ''}
                onChange={(e) => handleSelect(e.target.value)}
                disabled={loading || list.length === 0}
              >
                {list.map((q) => (
                  <option key={q.id} value={q.id}>{q.title || q.token}</option>
                ))}
              </select>
              {inlineMsg && (
                <div className="mt-1 text-xs text-destructive">{inlineMsg}</div>
              )}
            </div>

            <div>
              <label className="block text-xs text-muted-foreground mb-1" htmlFor="ref">Ref</label>
              <input
                id="ref"
                aria-label="ref"
                className="w-full px-2 py-2 text-sm bg-background border border-border rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                placeholder="landing / campaign / partner-code…"
                value={ref}
                onChange={(e) => setRef(e.target.value)}
              />
            </div>

            <div>
              <label className="block text-xs text-muted-foreground mb-1" htmlFor="lang">שפה</label>
              <select
                id="lang"
                aria-label="שפה"
                className="w-full px-2 py-2 text-sm bg-background border border-border rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                value={lang}
                onChange={(e) => setLang(e.target.value as Lang)}
              >
                <option value="he">Hebrew</option>
                <option value="en">English</option>
              </select>
            </div>
          </div>

          {/* פעולות */}
          <div className="flex flex-col sm:flex-row gap-2">
            <button
              type="button"
              onClick={handleCopy}
              disabled={!current}
              aria-label="העתק קישור"
              className="w-full sm:w-auto px-4 py-2 rounded-md bg-muted hover:bg-muted/80 disabled:opacity-60 disabled:cursor-not-allowed"
            >
              העתק קישור
            </button>
            <button
              type="button"
              onClick={() => setEmailDialogOpen(true)}
              disabled={!current}
              aria-label="שיתוף באימייל"
              className="w-full sm:w-auto px-4 py-2 rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-60 disabled:cursor-not-allowed"
            >
              שיתוף באימייל
            </button>
            <button
              type="button"
              onClick={handleWhatsApp}
              disabled={!current}
              aria-label="שיתוף בוואטסאפ"
              className="w-full sm:w-auto px-4 py-2 rounded-md bg-emerald-600 text-white hover:bg-emerald-700 disabled:opacity-60 disabled:cursor-not-allowed"
            >
              שיתוף ב־WhatsApp
            </button>
            <button
              type="button"
              onClick={() => setShareOpen(true)}
              disabled={!publicUrl}
              aria-label="פתח דיאלוג שיתוף"
              className="w-full sm:w-auto px-4 py-2 rounded-md bg-muted hover:bg-muted/80 disabled:opacity-60 disabled:cursor-not-allowed"
            >
              שיתוף…
            </button>
            <button
              type="button"
              onClick={handlePreview}
              disabled={!publicUrl}
              aria-label="תצוגה מקדימה"
              className="w-full sm:w-auto px-4 py-2 rounded-md bg-secondary text-secondary-foreground hover:bg-secondary/90 disabled:opacity-60 disabled:cursor-not-allowed"
            >
              תצוגה מקדימה
            </button>
            <button
              type="button"
              onClick={handleEdit}
              disabled={!current}
              aria-label="עריכת השאלון"
              className="w-full sm:w-auto px-4 py-2 rounded-md bg-muted hover:bg-muted/80 disabled:opacity-60 disabled:cursor-not-allowed"
            >
              עריכת השאלון
            </button>
          </div>

          {/* קישור + טקסט עזר */}
          <div className="flex flex-col sm:flex-row gap-2 items-start sm:items-center">
            <input
              readOnly
              value={publicUrl}
              aria-label="קישור להפצה"
              className="flex-1 px-3 py-2 bg-background border border-border rounded-md text-sm w-full"
            />
            <button
              type="button"
              onClick={handlePreview}
              disabled={!publicUrl}
              className="px-4 py-2 rounded-md bg-secondary text-secondary-foreground hover:bg-secondary/90 disabled:opacity-60 disabled:cursor-not-allowed"
            >
              פתח תצוגה
            </button>
          </div>
          <div className="text-[11px] text-muted-foreground">הקישור מתעדכן אוטומטית לפי הבחירות שלך</div>

          {/* QR */}
          <div className="mt-2">
            <label className="block text-xs text-muted-foreground mb-2">קוד QR</label>
            <img
              alt="QR"
              className="w-[256px] h-[256px] border border-border rounded-md"
              src={`https://api.qrserver.com/v1/create-qr-code/?size=256x256&data=${encodeURIComponent(publicUrl)}`}
            />
          </div>
        </div>

        {/* דיאלוג שיתוף */}
        <ShareDialog
          open={shareOpen}
          onOpenChange={setShareOpen}
          url={publicUrl}
          title={current?.title ?? 'שאלון'}
          subject={current?.title ?? 'שאלון'}
          body={current ? 'נשמח לפרט, מלא/י את השאלון' : undefined}
          whatsappTemplate={'היי! מוזמן/ת למלא: {link}'}
        />
      </div>
    </div>
  );
}
