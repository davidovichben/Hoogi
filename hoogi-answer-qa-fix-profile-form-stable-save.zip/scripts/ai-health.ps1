$Url  = "https://lcazbaggfdejukjgkpeu.supabase.co/functions/v1/getSuggestedQuestionsAI"
$ANON = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxjYXpiYWdnZmRlanVramdrcGV1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM2OTE4MjgsImV4cCI6MjA2OTI2NzgyOH0.nRiCK9o830N-ZXvVALxTd2pLkDRQIZ8aCnnlo48IA5M"
$Headers = @{ "apikey" = $ANON; "Authorization" = "Bearer $ANON" }
$Body    = '{"profile":{"name":"Test","email":"test@example.com","phone":"+972500000000","domain":"lawyer"},"count":1,"locale":"he"}'
$sw=[System.Diagnostics.Stopwatch]::StartNew()
try{
  $r=Invoke-RestMethod -Method POST -Uri $Url -Headers $Headers -ContentType "application/json" -Body $Body
  $sw.Stop()
  if($r.questions -and $r.questions.Count -ge 1){ Write-Host ("HEALTHY - {0} ms" -f $sw.ElapsedMilliseconds) -ForegroundColor Green } else { Write-Host ("PARTIAL - {0} ms" -f $sw.ElapsedMilliseconds) -ForegroundColor Yellow }
}catch{
  $sw.Stop()
  $code = $_.Exception.Response.StatusCode.Value__
  Write-Host ("DOWN - HTTP {0} ({1} ms)" -f $code,$sw.ElapsedMilliseconds) -ForegroundColor Red
  $sr = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream()); $err=$sr.ReadToEnd(); Write-Host $err
  exit 1
}