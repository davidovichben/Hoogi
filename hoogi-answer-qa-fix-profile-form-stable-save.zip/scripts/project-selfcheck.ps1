﻿# Hoogi Answer - Project Self-Check Script
# Validates project integrity before commits/merges

$ErrorActionPreference = "Stop"
function Log($m,$c="Gray"){ Write-Host $m -ForegroundColor $c }

Log "🔍 Starting Hoogi Answer Project Self-Check..." "Cyan"

# 1. Check TypeScript compilation
Log "📝 Checking TypeScript compilation..." "Yellow"
try {
  npx tsc --noEmit | Out-Host
  Log "✅ TypeScript compilation passed" "Green"
} catch {
  Log "❌ TypeScript compilation failed" "Red"
  exit 1
}

# 2. Check AI Edge Function health
Log "🤖 Checking AI Edge Function health..." "Yellow"
try {
  $Url = "https://lcazbaggfdejukjgkpeu.supabase.co/functions/v1/getSuggestedQuestionsAI"
  $ANON = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxjYXpiYWdnZmRlanVramdrcGV1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM2OTE4MjgsImV4cCI6MjA2OTI2NzgyOH0.nRiCK9o830N-ZXvVALxTd2pLkDRQIZ8aCnnlo48IA5M"
  $Headers = @{ "apikey" = $ANON; "Authorization" = "Bearer $ANON" }
  $Body = '{"profile":{"name":"Test","email":"test@example.com","phone":"+972500000000","domain":"lawyer"},"count":1,"locale":"he"}'
  
  $sw = [System.Diagnostics.Stopwatch]::StartNew()
  $r = Invoke-RestMethod -Method POST -Uri $Url -Headers $Headers -ContentType "application/json" -Body $Body -ErrorAction Stop
  $sw.Stop()
  
  if ($r.questions -and $r.questions.Count -ge 1) {
    Log "✅ AI Edge Function healthy - $($sw.ElapsedMilliseconds) ms" "Green"
  } else {
    Log "⚠️ AI Edge Function partial response - $($sw.ElapsedMilliseconds) ms" "Yellow"
  }
} catch {
  Log "❌ AI Edge Function check failed: $($_.Exception.Message)" "Red"
  # Don't exit on AI failure - it might be expected in DEV
}

# 3. Check required files exist
Log "📁 Checking required files..." "Yellow"
$requiredFiles = @(
  ".cursor/rules",
  "AGENTS.md", 
  "secrets.env",
  "supabase/functions/getSuggestedQuestionsAI/index.ts",
  "scripts/sb-deploy.ps1",
  "scripts/ai-invoke.ps1", 
  "scripts/ai-health.ps1"
)

$missingFiles = @()
foreach ($file in $requiredFiles) {
  if (-not (Test-Path $file)) {
    $missingFiles += $file
  }
}

if ($missingFiles.Count -gt 0) {
  Log "❌ Missing required files:" "Red"
  $missingFiles | ForEach-Object { Log "   - $_" "Red" }
  exit 1
} else {
  Log "✅ All required files present" "Green"
}

# 4. Check secrets.env format
Log "🔐 Checking secrets.env format..." "Yellow"
if (Test-Path "secrets.env") {
  $secretsContent = Get-Content "secrets.env" -Raw
  if ($secretsContent -match "GEMINI_API_KEY=" -and $secretsContent -match "AI_FALLBACK=") {
    Log "✅ secrets.env format valid" "Green"
  } else {
    Log "❌ secrets.env missing required keys (GEMINI_API_KEY, AI_FALLBACK)" "Red"
    exit 1
  }
} else {
  Log "❌ secrets.env not found" "Red"
  exit 1
}

# 5. Check package.json scripts
Log "📦 Checking package.json scripts..." "Yellow"
$packageJson = Get-Content "package.json" -Raw | ConvertFrom-Json
$requiredScripts = @("sb:deploy", "ai:invoke", "ai:health")
$missingScripts = @()

foreach ($script in $requiredScripts) {
  if (-not $packageJson.scripts.$script) {
    $missingScripts += $script
  }
}

if ($missingScripts.Count -gt 0) {
  Log "❌ Missing npm scripts:" "Red"
  $missingScripts | ForEach-Object { Log "   - $_" "Red" }
  exit 1
} else {
  Log "✅ All required npm scripts present" "Green"
}

Log "🎉 Project self-check completed successfully!" "Green"
Log "Ready for commit/merge." "Cyan"