param(
  [string]$ProjectRef = "lcazbaggfdejukjgkpeu",
  [string]$SecretsFile = ".\secrets.env"
)
$ErrorActionPreference = "Stop"

if (-not (Test-Path $SecretsFile)) { throw "secrets.env not found" }
$lines = Get-Content -Path $SecretsFile -Raw -Encoding UTF8 -ErrorAction Stop -TotalCount 9999
$map = @{}
$lines -split "`r?`n" | Where-Object { $_ -match "=" } | ForEach-Object {
  $k,$v = $_ -split "=",2; $map[$k.Trim()] = $v.Trim()
}
if (-not $map["GEMINI_API_KEY"]) { throw "GEMINI_API_KEY missing in secrets.env" }
if (-not $map["AI_FALLBACK"])   { $map["AI_FALLBACK"] = "1" }

Write-Host "🔗 Linking project..." -ForegroundColor Cyan
npx supabase@latest link --project-ref $ProjectRef | Out-Host

Write-Host "🔐 Setting secrets..." -ForegroundColor Cyan
npx supabase@latest secrets set GEMINI_API_KEY="$($map["GEMINI_API_KEY"])" | Out-Host
npx supabase@latest secrets set AI_FALLBACK="$($map["AI_FALLBACK"])" | Out-Host

Write-Host "🚀 Deploying function..." -ForegroundColor Cyan
npx supabase@latest functions deploy getSuggestedQuestionsAI | Out-Host

Write-Host "✅ Done." -ForegroundColor Green
