﻿param(
  [string]$Anon = "",
  [string]$Url  = "https://lcazbaggfdejukjgkpeu.supabase.co/functions/v1/getSuggestedQuestionsAI",
  [switch]$Pause
)
$ErrorActionPreference = "Stop"
function Log($m,$c="Gray"){ Write-Host $m -ForegroundColor $c }

if (-not $Anon) {
  $envFile = ".\.env.local"
  if (-not (Test-Path $envFile)) { Log "❌ .env.local not found" "Red"; if($Pause){Read-Host "Press Enter"}; return 1 }
  $envText = Get-Content -Path $envFile -Raw -Encoding UTF8
  $m = [regex]::Match($envText, 'VITE_SUPABASE_ANON_KEY\s*=\s*([^\r\n]+)')
  if (-not $m.Success) { Log "❌ VITE_SUPABASE_ANON_KEY missing" "Red"; if($Pause){Read-Host "Enter"}; return 1 }
  $Anon = $m.Groups[1].Value.Trim()
}
if ($Anon.Split('.').Count -ne 3) { Log "❌ Invalid ANON (must be 3 parts)" "Red"; if($Pause){Read-Host "Enter"}; return 1 }

$Headers = @{ "apikey" = $Anon; "Authorization" = "Bearer $Anon" }
$BodyObj = [ordered]@{
  profile = [ordered]@{ name="בדיקה"; email="test@example.com"; phone="+972500000000"; domain="lawyer"; about="עו""ד מקרקעין בת""א" }
  count = 5; locale = "he"
}
$BodyJson = ($BodyObj | ConvertTo-Json -Depth 8 -Compress)

$sw = [System.Diagnostics.Stopwatch]::StartNew()
try{
  $resp = Invoke-RestMethod -Method POST -Uri $Url -Headers $Headers -ContentType "application/json; charset=utf-8" -Body $BodyJson
  $sw.Stop()
  Log ("✅ OK — $(@($resp.questions).Count) questions in $($sw.ElapsedMilliseconds) ms") "Green"
  $resp | ConvertTo-Json -Depth 8
}catch{
  $sw.Stop()
  if ($_.Exception.Response) {
    $sr = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
    $err = $sr.ReadToEnd()
    Log ("❌ HTTP ERROR $($_.Exception.Response.StatusCode.Value__) — $($sw.ElapsedMilliseconds) ms") "Red"
    Write-Host $err
  } else {
    Log ("❌ ERROR: $($_.Exception.Message)") "Red"
  }
  if ($Pause){ Read-Host "Press Enter to exit" }
  return 1
}
if ($Pause){ Read-Host "Press Enter to exit" }