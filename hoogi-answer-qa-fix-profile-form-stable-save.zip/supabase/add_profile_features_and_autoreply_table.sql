-- Add plan_tier and questionnaires_quota to profiles table
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'plan_tier') THEN
        ALTER TABLE public.profiles ADD COLUMN plan_tier TEXT DEFAULT 'free';
        RAISE NOTICE 'Added plan_tier column to profiles table.';
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'questionnaires_quota') THEN
        ALTER TABLE public.profiles ADD COLUMN questionnaires_quota INTEGER DEFAULT 3;
        RAISE NOTICE 'Added questionnaires_quota column to profiles table.';
    END IF;
END $$;

-- Create auto_reply_settings table
CREATE TABLE IF NOT EXISTS public.auto_reply_settings (
    id UUID PRIMARY KEY REFERENCES public.questionnaires(id) ON DELETE CASCADE,
    enabled BOOLEAN DEFAULT FALSE,
    tone TEXT,
    subject_template TEXT,
    body_template TEXT,
    user_preamble TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security (RLS) for auto_reply_settings
ALTER TABLE public.auto_reply_settings ENABLE ROW LEVEL SECURITY;

-- Policy for authenticated users to view their own auto_reply_settings
CREATE POLICY "Allow authenticated users to view their own auto_reply_settings"
ON public.auto_reply_settings FOR SELECT
TO authenticated
USING ((SELECT profile_id FROM public.questionnaires WHERE id = auto_reply_settings.id) = auth.uid());

-- Policy for authenticated users to insert their own auto_reply_settings
CREATE POLICY "Allow authenticated users to insert their own auto_reply_settings"
ON public.auto_reply_settings FOR INSERT
TO authenticated
WITH CHECK ((SELECT profile_id FROM public.questionnaires WHERE id = auto_reply_settings.id) = auth.uid());

-- Policy for authenticated users to update their own auto_reply_settings
CREATE POLICY "Allow authenticated users to update their own auto_reply_settings"
ON public.auto_reply_settings FOR UPDATE
TO authenticated
USING ((SELECT profile_id FROM public.questionnaires WHERE id = auto_reply_settings.id) = auth.uid());

-- Set up Realtime for auto_reply_settings table (optional)
ALTER PUBLICATION supabase_realtime ADD TABLE IF NOT EXISTS public.auto_reply_settings;

