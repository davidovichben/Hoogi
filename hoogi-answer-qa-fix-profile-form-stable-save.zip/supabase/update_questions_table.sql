-- Update public.questions table with new columns
DO $$
BEGIN
    -- Add 'type' column
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'questions' AND column_name = 'type') THEN
        ALTER TABLE public.questions ADD COLUMN type TEXT NOT NULL DEFAULT 'short_text';
        RAISE NOTICE 'Added type column to questions table.';
    END IF;
    
    -- Add CHECK constraint for 'type' column (if not exists or needs update)
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'questions_type_check' AND conrelid = 'public.questions'::regclass) THEN
        ALTER TABLE public.questions ADD CONSTRAINT questions_type_check 
            CHECK (type IN ('short_text', 'long_text', 'multiple_choice', 'checkbox', 'phone', 'email', 'file', 'number', 'date'));
        RAISE NOTICE 'Added questions_type_check constraint.';
    END IF;

    -- Add 'allow_voice_input' column
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'questions' AND column_name = 'allow_voice_input') THEN
        ALTER TABLE public.questions ADD COLUMN allow_voice_input BOOLEAN DEFAULT FALSE;
        RAISE NOTICE 'Added allow_voice_input column to questions table.';
    END IF;

    -- Add 'order_index' column
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'questions' AND column_name = 'order_index') THEN
        ALTER TABLE public.questions ADD COLUMN order_index INTEGER;
        RAISE NOTICE 'Added order_index column to questions table.';
    END IF;
    -- Update existing rows to have a default order_index
    EXECUTE 'UPDATE public.questions SET order_index = (SELECT row_number() OVER (PARTITION BY questionnaire_id ORDER BY created_at)) WHERE order_index IS NULL';
    -- Make order_index NOT NULL after setting default values
    ALTER TABLE public.questions ALTER COLUMN order_index SET NOT NULL;
    RAISE NOTICE 'Updated order_index for existing questions and set NOT NULL constraint.';

    -- Add 'options' column (for multiple_choice, checkbox)
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'questions' AND column_name = 'options') THEN
        ALTER TABLE public.questions ADD COLUMN options JSONB;
        RAISE NOTICE 'Added options column to questions table.';
    END IF;

    -- Add 'partner_id' column (if not exists)
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'questions' AND column_name = 'partner_id') THEN
        ALTER TABLE public.questions ADD COLUMN partner_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL;
        RAISE NOTICE 'Added partner_id column to questions table.';
    END IF;

    -- Add 'title' column (if not exists) - from questionnaire.title_i18n
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'questions' AND column_name = 'title') THEN
        ALTER TABLE public.questions ADD COLUMN title TEXT;
        RAISE NOTICE 'Added title column to questions table.';
    END IF;

END $$;

-- Ensure RLS is enabled for questions table
ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;

-- Policy for authenticated users to view their own questions
CREATE POLICY "Allow authenticated users to view their own questions"
ON public.questions FOR SELECT
TO authenticated
USING ((SELECT profile_id FROM public.questionnaires WHERE id = questionnaire_id) = auth.uid());

-- Policy for authenticated users to insert their own questions
CREATE POLICY "Allow authenticated users to insert their own questions"
ON public.questions FOR INSERT
TO authenticated
WITH CHECK ((SELECT profile_id FROM public.questionnaires WHERE id = questionnaire_id) = auth.uid());

-- Policy for authenticated users to update their own questions
CREATE POLICY "Allow authenticated users to update their own questions"
ON public.questions FOR UPDATE
TO authenticated
USING ((SELECT profile_id FROM public.questionnaires WHERE id = questionnaire_id) = auth.uid());

-- Policy for authenticated users to delete their own questions
CREATE POLICY "Allow authenticated users to delete their own questions"
ON public.questions FOR DELETE
TO authenticated
USING ((SELECT profile_id FROM public.questionnaires WHERE id = questionnaire_id) = auth.uid());

-- Set up Realtime for questions table (optional)
ALTER PUBLICATION supabase_realtime ADD TABLE IF NOT EXISTS public.questions;

