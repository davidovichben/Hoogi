import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY')!;
const FROM_EMAIL = Deno.env.get('REPLY_FROM_EMAIL') ?? 'noreply@example.com';

async function sendEmail(to: string, subject: string, body: string) {
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${RESEND_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: FROM_EMAIL, to, subject, text: body })
  });
  if (!res.ok) throw new Error(await res.text());
}

serve(async () => {
  try {
    const { data: rows, error } = await supabase
      .from('message_outbox')
      .select('id, to_email, subject, body')
      .eq('status','pending')
      .limit(50);
    if (error) throw error;

    for (const row of rows ?? []) {
      try {
        await sendEmail(row.to_email, row.subject, row.body);
        await supabase.from('message_outbox')
          .update({ status:'sent', sent_at: new Date().toISOString(), error_msg: null })
          .eq('id', row.id);
      } catch (e) {
        await supabase.from('message_outbox')
          .update({ status:'failed', error_msg: String(e) })
          .eq('id', row.id);
      }
    }
    return new Response('ok', { status: 200 });
  } catch (e) {
    console.error(e);
    return new Response('error', { status: 500 });
  }
});
