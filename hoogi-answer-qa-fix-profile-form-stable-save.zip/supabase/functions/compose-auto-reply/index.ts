// deno-lint-ignore-file no-explicit-any
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
const REPLY_FROM_EMAIL = Deno.env.get("REPLY_FROM_EMAIL") ?? "noreply@ai-4biz.com";
const REPLY_FROM_NAME  = Deno.env.get("REPLY_FROM_NAME")  ?? "Hoogi";

const sb = createClient(SUPABASE_URL, SERVICE_ROLE);

type DB = any;

async function sendWithResend(to: string, subject: string, html: string) {
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${RESEND_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from: `${REPLY_FROM_NAME} <${REPLY_FROM_EMAIL}>`,
      to: [to],
      subject,
      html,
    }),
  });
  const j = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(`Resend failed ${res.status}: ${JSON.stringify(j)}`);
  }
  return j;
}

function buildAutoReply(name: string | null, businessName: string | null) {
  const title = businessName ?? "תודה שפנית אלינו";
  const subject = "תודה שפנית אלינו";
  const bodyHtml = `
    <div dir="rtl" style="font-family:Arial,Helvetica,sans-serif">
      <p>${name ? `${name} שלום,` : "שלום,"}</p>
      <p>תודה שפנית אלינו. קיבלנו את פנייתך ואנו נחזור אליך בהקדם.</p>
      <p>בברכה,<br/>${businessName ?? "הצוות שלנו"}</p>
    </div>
  `;
  return { subject, html: bodyHtml, title };
}

async function upsertOutbox(responseId: string, to: string, subject: string, body: string, status: "pending"|"sent"|"failed", error_msg?: string|null) {
  const { error } = await sb
    .from("message_outbox")
    .upsert({
      response_id: responseId,
      to_email: to,
      subject,
      body,
      status,
      error_msg: error_msg ?? null,
    }, { onConflict: "response_id,to_email,subject", ignoreDuplicates: false });
  if (error) throw error;
}

Deno.serve(async (req) => {
  try {
    const payload = await req.json().catch(() => ({} as any));

    // webhook מה-DB שולח body עם record; אם זה קריאה ידנית – אפשר להעביר response_id ב-body
    const responseId: string | undefined =
      payload?.record?.id ?? payload?.response_id;

    if (!responseId) {
      return new Response("missing response_id", { status: 400 });
    }

    // מביאים את הרשומה והפרטים לשולח + מייל יעד (respondent)
    // שדות רלוונטיים: profiles.business_name, responses.respondent_contact->>'email' וכו'
    const { data: resp, error: e1 } = await sb
      .from("responses")
      .select(`
        id,
        respondent_contact,
        questionnaire_id,
        meta
      `)
      .eq("id", responseId)
      .single();

    if (e1 || !resp) throw e1 ?? new Error("response not found");

    const respondent = (resp.respondent_contact ?? {}) as { name?: string; email?: string; phone?: string };
    const toEmail = respondent.email;
    if (!toEmail) {
      // אין למי לשלוח – נרשום outbox "failed" ונצא בהצלחה (כדי לא להפיל webhook)
      await upsertOutbox(responseId, "", "auto-reply (missing email)", "no recipient", "failed", "missing recipient email");
      return new Response(JSON.stringify({ ok: true, skipped: "no email" }), { status: 200 });
    }

    // מביאים פרטי פרופיל בשביל שם עסק/מיתוג
    const ownerId = (resp.meta?.owner_id ?? null) as string | null;
    let businessName: string | null = null;
    if (ownerId) {
      const { data: prof } = await sb.from("profiles")
        .select("business_name")
        .eq("id", ownerId)
        .maybeSingle();
      businessName = prof?.business_name ?? null;
    }

    const { subject, html } = buildAutoReply(respondent.name ?? null, businessName);

    // נשלח מייל מייד (בלי Scheduler)
    let sendError: string | null = null;
    try {
      await sendWithResend(toEmail, subject, html);
    } catch (err) {
      sendError = String(err instanceof Error ? err.message : err);
    }

    // נרשום גם ל-outbox (עם onConflict כדי למנוע כפילות)
    await upsertOutbox(responseId, toEmail, subject, html, sendError ? "failed" : "sent", sendError);

    return new Response(JSON.stringify({ ok: !sendError, error: sendError }), { status: 200 });
  } catch (err) {
    return new Response(String(err instanceof Error ? err.message : err), { status: 500 });
  }
});