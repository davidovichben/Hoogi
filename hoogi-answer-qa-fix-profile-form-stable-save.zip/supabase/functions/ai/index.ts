﻿import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const ORIGINS = ["http://localhost:8080", "https://ai-4biz.com"];

const GEMINI_KEY = Deno.env.get("GOOGLE_API_KEY");
const MODEL = "gemini-2.5-flash";
const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`;

function corsHeaders(req: Request) {
  const reqOrigin = req.headers.get("origin") ?? "";
  const allow = ORIGINS.includes(reqOrigin) ? reqOrigin : "null";
  return {
    "content-type": "application/json; charset=utf-8",
    "access-control-allow-origin": allow,
    "access-control-allow-headers": "authorization, content-type",
    "access-control-allow-methods": "POST, OPTIONS",
  };
}
function cors(req: Request, status = 200, body: unknown = "") {
  return new Response(typeof body === "string" ? body : JSON.stringify(body), {
    status,
    headers: corsHeaders(req),
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return cors(req, 204, "");

  try {
    if (!GEMINI_KEY) return cors(req, 500, { error: "missing GOOGLE_API_KEY" });

    const { prompt } = await req.json().catch(() => ({}));
    if (!prompt || typeof prompt !== "string") {
      return cors(req, 400, { error: "missing 'prompt' (string)" });
    }

    // health check – אם שולחים "ping" חוזר "pong"
    if (prompt.toLowerCase() === "ping") {
      return cors(req, 200, { ok: true, text: "pong" });
    }

    const r = await fetch(GEMINI_URL, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-goog-api-key": GEMINI_KEY,
      },
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ text: prompt + " (ענה/י בעברית)" }] }],
      }),
    });

    const data = await r.json();
    if (!r.ok) return cors(req, r.status, { error: "provider_error", details: data });

    const text =
      data?.candidates?.[0]?.content?.parts
        ?.map((p: any) => p?.text)
        ?.filter(Boolean)
        ?.join("\n") ?? "";

    return cors(req, 200, { ok: true, text });
  } catch (e) {
    return cors(req, 500, { error: "server_error", message: String(e) });
  }
});