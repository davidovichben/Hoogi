import { serve } from "https://deno.land/std@0.224.0/http/server.ts";

type Profile = {
  name: string; email: string; phone: string;
  domain: string; domain_text?: string;
  website?: string;
  social?: Partial<Record<"facebook"|"instagram"|"tiktok"|"linkedin"|"youtube"|"twitter", string>>;
  location?: string; languages?: string[]; about?: string;
  [k: string]: unknown;
};

type AiQuestion = {
  id_temp: string;
  title: string;
  type: "text"|"single_select"|"multi_select"|"email"|"phone"|"date";
  options?: string[]; required?: boolean; other_free_text?: boolean;
};

/** חילוץ JSON גם אם הגיע בתוך ```json ...``` או עם טקסט עודף */
function extractJsonObject(text: string): any {
  // 1) נסה JSON נקי
  try { return JSON.parse(text); } catch {}
  // 2) בתוך גדרות ```json
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
  if (fenced?.[1]) { try { return JSON.parse(fenced[1].trim()); } catch {} }
  // 3) בין הסוגר המסולסל הראשון לאחרון
  const first = text.indexOf("{"); const last = text.lastIndexOf("}");
  if (first !== -1 && last > first) { try { return JSON.parse(text.slice(first, last+1)); } catch {} }
  return null;
}

/** שאלות גיבוי חכמות – כדי שלא ניחסם בבדיקות/DEV */
function fallbackQuestions(profile: Profile, count = 5): AiQuestion[] {
  const d = profile.domain === "other" ? (profile.domain_text || "התחום שלך") : profile.domain;
  const bank: string[] = [
    `מהי המטרה המרכזית שלך ב${d}?`,
    `אילו שירותים/מוצרים תרצה להדגיש ב${d}?`,
    `מי קהל היעד העיקרי?`,
    `מה התקציב החודשי המשוער?`,
    `באיזו תדירות תרצה ליווי/עדכונים?`
  ];
  return bank.slice(0, count).map((title, i) => ({
    id_temp: `ai_fallback_${i+1}`,
    title,
    type: "text",
    required: true
  }));
}

async function callGemini(apiKey: string, prompt: string) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent?key=${apiKey}`;
  const body = {
    contents: [{ role: "user", parts: [{ text: prompt }] }],
    generationConfig: {
      temperature: 0.6,
      maxOutputTokens: 800,
      // מבקש JSON בלבד – מונע פלצורים
      response_mime_type: "application/json",
    },
  };
  const resp = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  return resp;
}

serve(async (req) => {
  try {
    if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405 });

    const apiKey = Deno.env.get("GEMINI_API_KEY");         // מוגדר כ-Secret
    const allowFallback = (Deno.env.get("AI_FALLBACK") ?? "1") !== "0"; // ברירת מחדל: לא לחסום

    const { profile, count = 5, locale = "he" } = await req.json() as {
      profile: Profile; count?: number; locale?: "he"|"en"
    };

    // ולידציות מינימליות
    if (!profile?.name || !profile?.email || !profile?.phone) {
      return new Response(JSON.stringify({ error: "missing name/email/phone" }), { status: 400 });
    }
    if (!profile?.domain) return new Response(JSON.stringify({ error: "missing domain" }), { status: 400 });
    if (profile.domain === "other" && !profile.domain_text) {
      return new Response(JSON.stringify({ error: "domain_text required" }), { status: 400 });
    }

    const isHe = locale === "he";
    const intro = isHe
      ? "הינך עוזר מומחה לבניית שאלון קצר ליצירת לידים."
      : "You are an expert assistant for crafting a short lead-capture questionnaire.";

    const instructions = isHe
      ? `החזר אך ורק JSON חוקי ללא טקסט נוסף, במבנה:
{"questions":[{ "id_temp":"ai_q1","title":"...","type":"text|single_select|multi_select|email|phone|date","options":["..."],"required":true,"other_free_text":false }, ...]}
צור בדיוק ${count} שאלות תחום. אין פרטי קשר. כשמתאים, החזר options ו-"אחר" עם other_free_text=true.`
      : `Return strictly JSON only:
{"questions":[{ "id_temp":"ai_q1","title":"...","type":"text|single_select|multi_select|email|phone|date","options":["..."],"required":true,"other_free_text":false }, ...]}
Exactly ${count} domain questions. No contact fields. Include options and Other+other_free_text=true where relevant.`;

    // אם אין מפתח – החזר גיבוי כדי לא לחסום DEV
    if (!apiKey) {
      const q = fallbackQuestions(profile, count);
      return new Response(JSON.stringify({ questions: q, source: "fallback_no_api_key" }), { headers: { "Content-Type": "application/json" }, status: 200 });
    }

    // נסיונות חוזרים (עד 2) לפני fallback
    const prompt = `${intro}\n\nPROFILE:\n${JSON.stringify(profile, null, 2)}\n\n${instructions}`;
    let lastText = "";
    for (let attempt = 1; attempt <= 2; attempt++) {
      const resp = await callGemini(apiKey, prompt);
      if (resp.ok) {
        const data = await resp.json();
        const text = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
        lastText = String(text);
        const parsed = extractJsonObject(lastText);
        if (parsed?.questions && Array.isArray(parsed.questions)) {
          const out: AiQuestion[] = parsed.questions.slice(0, count).map((q: any, i: number) => ({
            id_temp: (q?.id_temp ?? `ai_q${i + 1}`).toString(),
            title: String(q?.title ?? "").trim(),
            type: (q?.type ?? "text"),
            options: Array.isArray(q?.options) ? q.options.map((o: any) => String(o)) : undefined,
            required: typeof q?.required === "boolean" ? q.required : true,
            other_free_text: !!q?.other_free_text,
          }));
          return new Response(JSON.stringify({ questions: out, source: "ai" }), {
            headers: { "Content-Type": "application/json" },
            status: 200,
          });
        }
      } else {
        // שגיאת API: אם המפתח לא תקף – שוב לא יעזור, נשבור
        if (resp.status === 400 || resp.status === 401 || resp.status === 403) {
          const details = await resp.text();
          if (allowFallback) {
            const q = fallbackQuestions(profile, count);
            return new Response(JSON.stringify({ questions: q, source: "fallback_ai_error", details }), { headers: { "Content-Type": "application/json" }, status: 200 });
          }
          return new Response(JSON.stringify({ error: "gemini_failed", details }), { status: 502 });
        }
        // שגיאה זמנית – ננסה ניסיון נוסף
        await new Promise((r) => setTimeout(r, 250));
      }
    }

    // אם לא הצליח – fallback
    if (allowFallback) {
      const q = fallbackQuestions(profile, count);
      return new Response(JSON.stringify({ questions: q, source: "fallback_bad_ai_format", raw: lastText }), { headers: { "Content-Type": "application/json" }, status: 200 });
    }
    return new Response(JSON.stringify({ error: "bad_ai_format", raw: lastText }), { status: 500 });

  } catch (e) {
    // נסיון אחרון: גיבוי גם כאן כדי שלא ניחסם
    try {
      const { profile, count = 5 } = await req.json();
      const q = fallbackQuestions(profile, count);
      return new Response(JSON.stringify({ questions: q, source: "fallback_exception", err: String(e) }), { headers: { "Content-Type": "application/json" }, status: 200 });
    } catch {
      return new Response(JSON.stringify({ error: "server_error", details: String(e) }), { status: 500 });
    }
  }
});