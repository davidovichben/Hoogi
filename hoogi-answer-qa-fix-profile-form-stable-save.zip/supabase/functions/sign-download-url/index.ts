import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);

serve(async (req) => {
  try {
    const { path, expiresIn = 300 } = await req.json(); // ברירת מחדל: 5 דקות
    if (!path) return new Response('path required', { status: 400 });

    const ttl = Math.min(Math.max(Number(expiresIn) || 300, 30), 3600); // 30s..1h
    const { data, error } = await supabase.storage
      .from('questionnaire-uploads')
      .createSignedUrl(path, ttl);
    if (error) throw error;

    return new Response(JSON.stringify({ url: data.signedUrl }), {
      status: 200, headers: { 'Content-Type':'application/json' }
    });
  } catch (e) {
    console.error(e);
    return new Response('error', { status: 500 });
  }
});






