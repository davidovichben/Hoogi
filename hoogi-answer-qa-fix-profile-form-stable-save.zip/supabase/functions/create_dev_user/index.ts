// create_dev_user / index.ts
// DEV ONLY. יוצר משתמש אם חסר בעזרת Service Role כדי שהשמירות יעברו RLS גם ב-DEV.

import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const APP_ENV = Deno.env.get("APP_ENV");
const DEV_TOKEN = Deno.env.get("DEV_FUNCTION_TOKEN");

const admin = createClient(SUPABASE_URL, SERVICE_KEY);

serve(async (req) => {
  try {
    if (APP_ENV !== "dev") return new Response("Forbidden", { status: 403 });
    if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405 });

    if (!DEV_TOKEN || req.headers.get("x-dev-token") !== DEV_TOKEN) {
      return new Response("Unauthorized", { status: 401 });
    }

    const { email, password } = await req.json() as { email: string; password: string };
    if (!email || !password) return new Response("missing email/password", { status: 400 });

    const { data, error } = await admin.auth.admin.createUser({
      email, password, email_confirm: true, user_metadata: { is_dev_user: true }
    });

    if (error) {
      if (String(error.message || "").toLowerCase().includes("already registered")) {
        return new Response(JSON.stringify({ status: "exists" }), { status: 200 });
      }
      return new Response(JSON.stringify({ error: error.message }), { status: 400 });
    }

    return new Response(JSON.stringify({ status: "created", user_id: data.user?.id }), { status: 200 });
  } catch (e) {
    return new Response(JSON.stringify({ error: "server_error", details: String(e) }), { status: 500 });
  }
});

