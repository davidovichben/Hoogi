// supabase/functions/suggest-questions/index.ts
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

type Payload = {
  businessName?: string;
  occupation?: string;
  suboccupation?: string;
  category?: string | null;
  sources?: Array<{ kind: string; url?: string; title?: string; file_path?: string }>;
  language?: "he"|"en"|"fr";
  max?: number;
  __debug?: boolean; // enables verbose output on errors
};

const ok = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { "Content-Type": "application/json" }});

/** GET /health – בודק חיבורים וסודות (בלי לחשוף ערכים) */
async function health(req: Request) {
  const url = new URL(req.url);
  if (req.method === "GET" && url.pathname.endsWith("/health")) {
    return ok({
      ok: true,
      hasGeminiKey: !!Deno.env.get("GEMINI_API_KEY"),
      hasOpenAIKey: !!Deno.env.get("OPENAI_API_KEY"),
      geminiModel: Deno.env.get("GEMINI_MODEL") || "gemini-1.5-flash",
    });
  }
  return null;
}

function buildPrompt(p: Payload) {
  const hints: string[] = [];
  (p.sources ?? []).slice(0, 6).forEach(s => {
    if (s.title) hints.push(s.title);
    if (s.url) hints.push(s.url);
    if (s.file_path) hints.push(`file:${s.file_path}`);
  });

  const lang = p.language ?? "he";
  const head =
    lang === "he"
      ? `הפק ${p.max ?? 5} שאלות קצרות וממוקדות לשאלון. החזר אך ורק JSON שהוא מערך מחרוזות.`
      : `Generate ${p.max ?? 5} short, crisp questionnaire questions. Return ONLY a JSON array of strings.`;

  const body = `Business: ${p.businessName ?? ""}
Occupation: ${p.occupation ?? ""}, Sub: ${p.suboccupation ?? ""}
Category: ${p.category ?? ""}
Hints:
${hints.join("\n")}`;

  return `${head}\n\n${body}`;
}

function parseToArray(maybe: unknown): string[] {
  if (Array.isArray(maybe)) return maybe.map(String).filter(Boolean);
  if (typeof maybe === "string") {
    // נסה לפרש כמערך JSON, ואם לא—פרק לשורות
    try { const j = JSON.parse(maybe); return parseToArray(j); } catch {}
    return maybe.split(/\r?\n/).map(s => s.replace(/^\s*[-•\d.]+\s*/, "").trim()).filter(Boolean);
  }
  if (maybe && typeof maybe === "object") {
    // חפש שדות נפוצים
    const any = (maybe as any);
    if (Array.isArray(any.items)) return any.items.map(String).filter(Boolean);
    if (Array.isArray(any.data)) return any.data.map(String).filter(Boolean);
    if (typeof any.text === "string") return parseToArray(any.text);
    if (Array.isArray(any.candidates)) {
      for (const c of any.candidates) {
        const t = c?.content?.parts?.[0]?.text ?? c?.content?.parts?.[0]?.raw;
        const arr = parseToArray(t);
        if (arr.length) return arr;
      }
    }
  }
  return [];
}

serve(async (req: Request) => {
  // health endpoint
  const h = await health(req);
  if (h) return h;

  if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405 });

  try {
    const payload = (await req.json()) as Payload;
    const max = Math.min(Math.max(payload.max ?? 5, 2), 6);
    payload.max = max;

    const GEMINI_API_KEY = Deno.env.get("GEMINI_API_KEY") || "";
    const GEMINI_MODEL = Deno.env.get("GEMINI_MODEL") || "gemini-1.5-flash"; // אפשר לשים "gemini-1.5-pro" / "gemini-2.0-flash"
    const OPENAI_API_KEY = Deno.env.get("OPENAI_API_KEY") || "";
    const prompt = buildPrompt(payload);

    // 1) GEMINI קודם
    if (GEMINI_API_KEY) {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_API_KEY}`;
      const body = {
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.4, responseMimeType: "application/json" }
      };
      const r = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });

      const j = await r.json().catch(() => ({}));
      if (!r.ok) {
        if (payload.__debug) console.log("Gemini error:", r.status, j);
        // ננסה OpenAI או Fallback
      } else {
        const arr = parseToArray(j).slice(0, max);
        if (arr.length) return ok(arr);
        if (payload.__debug) console.log("Gemini returned empty after parse:", JSON.stringify(j).slice(0, 300));
      }
    }

    // 2) OpenAI אם קיים
    if (OPENAI_API_KEY) {
      const r = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${OPENAI_API_KEY}` },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [
            { role: "system", content: "Return ONLY a JSON array of strings of suggested questions." },
            { role: "user", content: prompt },
          ],
          temperature: 0.4,
        }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) {
        if (payload.__debug) console.log("OpenAI error:", r.status, j);
      } else {
        const content = j?.choices?.[0]?.message?.content ?? "[]";
        const arr = parseToArray(content).slice(0, max);
        if (arr.length) return ok(arr);
        if (payload.__debug) console.log("OpenAI returned empty after parse:", content?.slice?.(0, 300));
      }
    }

    // 3) Fallback בטוח
    const base = [
      "מה השירות המרכזי שנדרש כעת?",
      "מה חשוב לך בתהליך (מהירות/מחיר/מוניטין/ליווי)?",
      "יש פרטים/מסמכים שכדאי שנכיר?",
      "מה התוצאה שהכי תשמח/י לקבל?"
    ].slice(0, max);

    return ok(base);
  } catch (e) {
    return ok({ error: String(e) }, 500);
  }
});