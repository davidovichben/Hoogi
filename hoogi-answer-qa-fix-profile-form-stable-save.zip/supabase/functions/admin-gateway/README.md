# Admin Gateway

Edge Function שמספק גישה אדמיניסטרטיבית מלאה ל-Supabase עם אימות ובדיקות אבטחה.

## Security Features

### 🔐 **Dual Token Support**
- **Environment Secret**: `ADMIN_GATEWAY_TOKEN` (מומלץ לפרודקשן)
- **Inline Token**: `INLINE_ADMIN_TOKEN` (לפיתוח - החלפה שבועית)
- **Priority**: Inline token → Environment secret

### ⚠️ **Security Warnings**
- **Production**: השתמש ב-Secrets בלבד, אל תשמור טוקנים בקוד
- **Development**: אם משתמש ב-inline token, החלף אותו שבועית
- **Repository**: אם יש inline token, אל תעלה לריפו ציבורי

## Environment Variables

```bash
# Required
SUPABASE_URL=your_supabase_url
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key

# Authentication (choose one)
ADMIN_GATEWAY_TOKEN=your_secret_token  # Recommended for production
# OR use INLINE_ADMIN_TOKEN in code (for development only)

# Optional
ADMIN_ALLOW_ORIGIN=*  # CORS origin (default: *)
ADMIN_MAX_LIMIT=10000 # Max records per query (default: 10000)
```

## Authentication

כל בקשה חייבת לכלול:
```
Authorization: Bearer YOUR_TOKEN
```

**Token Sources (in priority order):**
1. `INLINE_ADMIN_TOKEN` (if not empty)
2. `ADMIN_GATEWAY_TOKEN` environment variable
3. Empty string (will reject all requests)

## Supported Actions

### Database Operations
- `select` - Query tables with filtering, ordering, limits
- `insert` - Insert new records
- `update` - Update existing records
- `delete` - Delete records
- `rpc` - Call stored procedures

### Storage Operations
- `storage.list` - List files in bucket
- `storage.put` - Upload file (base64 encoded)
- `storage.get` - Get signed download URL
- `storage.remove` - Delete file

### Auth Operations
- `auth.invite` - Invite user by email
- `auth.list` - List all users

## Usage Examples

### Select Records
```bash
curl -X POST [supabase-url]/functions/v1/admin-gateway \
  -H 'Authorization: Bearer YOUR_TOKEN' \
  -H 'Content-Type: application/json' \
  -d '{
    "action": "select",
    "table": "profiles",
    "match": {"industry": "technology"},
    "options": {
      "columns": "id, business_name, email",
      "limit": 50,
      "order": {"column": "created_at", "ascending": false}
    }
  }'
```

### Update Records
```bash
curl -X POST [supabase-url]/functions/v1/admin-gateway \
  -H 'Authorization: Bearer YOUR_TOKEN' \
  -H 'Content-Type: application/json' \
  -d '{
    "action": "update",
    "table": "profiles",
    "match": {"id": "user-uuid"},
    "payload": {"business_name": "New Company Name"}
  }'
```

### Upload File
```bash
curl -X POST [supabase-url]/functions/v1/admin-gateway \
  -H 'Authorization: Bearer YOUR_TOKEN' \
  -H 'Content-Type: application/json' \
  -d '{
    "action": "storage.put",
    "bucket": "questionnaires",
    "path": "uploads/file.pdf",
    "payload": {
      "contentBase64": "base64-encoded-content",
      "contentType": "application/pdf"
    }
  }'
```

### Call RPC Function
```bash
curl -X POST [supabase-url]/functions/v1/admin-gateway \
  -H 'Authorization: Bearer YOUR_TOKEN' \
  -H 'Content-Type: application/json' \
  -d '{
    "action": "rpc",
    "rpc": "normalize_phone",
    "payload": {"_p": "+972501234567"}
  }'
```

## Security Features

- **Token Authentication**: כל בקשה חייבת להכיל טוקן תקין
- **Table Validation**: בדיקת שמות טבלאות נגד regex ורשימת חסימה
- **CORS Support**: תמיכה ב-CORS headers
- **Rate Limiting**: הגבלת מספר רשומות לכל שאילתה
- **Error Handling**: טיפול מקיף בשגיאות

## Table Access Control

כרגע מתיר גישה לכל הטבלאות ב-public schema. ניתן להוסיף טבלאות לרשימת החסימה:

```typescript
const DENY_LIST = new Set<string>([
  "sensitive_table",
  "admin_logs"
]);
```
