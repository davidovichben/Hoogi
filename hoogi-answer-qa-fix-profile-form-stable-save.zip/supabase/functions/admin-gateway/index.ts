// Admin Gateway — Full access for development (Service Role on server-side)
// ⚠ חשוב: הטוקן כאן הוא זמני לפיתוח. החליפי/סגרי אותו אחת לשבוע.
const INLINE_ADMIN_TOKEN = "d21bcca0-365e-4d7d-8f50-12805dbf6249511820d0b32f4936";

import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// CORS: בלוקאל אפשר "*". בפרודקשן הגדירי דומיין ב-Secret ADMIN_ALLOW_ORIGIN
const ALLOW_ORIGIN = Deno.env.get("ADMIN_ALLOW_ORIGIN") || "*";
const cors = {
  "access-control-allow-origin": ALLOW_ORIGIN,
  "access-control-allow-methods": "POST, OPTIONS, GET",
  "access-control-allow-headers": "authorization, content-type",
};

const SUPABASE_URL  = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY   = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const ADMIN_TOKEN   =
  (INLINE_ADMIN_TOKEN && INLINE_ADMIN_TOKEN.trim()) ||
  Deno.env.get("ADMIN_GATEWAY_TOKEN") ||
  "";

const MAX_LIMIT = Number(Deno.env.get("ADMIN_MAX_LIMIT") || 10000);
const admin = createClient(SUPABASE_URL, SERVICE_KEY);

type Action =
  | "select" | "insert" | "update" | "delete"
  | "rpc"
  | "storage.list" | "storage.put" | "storage.get" | "storage.remove"
  | "auth.invite" | "auth.list";

type Body = {
  action: Action;
  table?: string;
  match?: Record<string, unknown>;
  payload?: any;
  options?: {
    columns?: string;
    limit?: number;
    order?: { column: string; ascending?: boolean };
  };
  rpc?: string;
  bucket?: string;
  path?: string;
};

// מאשרים כל שם טבלה חוקי; אפשר לחסום שמות ספציפיים ב-DENY_LIST
const TABLE_NAME_RE = /^[a-zA-Z0-9_]+$/;
const DENY_LIST = new Set<string>([]);
function isAllowedPublicTable(name?: string | null) {
  if (!name) return false;
  if (!TABLE_NAME_RE.test(name)) return false;
  if (DENY_LIST.has(name)) return false;
  return true;
}

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json", ...cors },
  });
}

serve(async (req) => {
  // Preflight / Health
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method === "GET")     return json({ ok: true, name: "admin_gateway" });

  // Custom token authentication (bypass Supabase JWT validation)
  const auth = req.headers.get("authorization") ?? "";
  const customToken = auth.replace("Bearer ", "");
  
  if (!ADMIN_TOKEN || customToken !== ADMIN_TOKEN) {
    return json({ error: "Unauthorized" }, 401);
  }

  try {
    const body = (await req.json()) as Body;
    const { action, table, match, payload, options, rpc, bucket, path } = body;

    if (table && !isAllowedPublicTable(table)) {
      return json({ error: `Table '${table}' not allowed` }, 400);
    }

    switch (action) {
      // ---------- Tables ----------
      case "select": {
        const q = admin.from(table!).select(options?.columns ?? "*");
        if (options?.order) {
          q.order(options.order.column, { ascending: options.order.ascending ?? true });
        }
        const { data, error } = await q
          .match(match ?? {})
          .limit(Math.min(options?.limit ?? MAX_LIMIT, MAX_LIMIT));
        if (error) throw error;
        return json({ data });
      }
      case "insert": {
        const { data, error } = await admin.from(table!).insert(payload).select();
        if (error) throw error;
        return json({ data });
      }
      case "update": {
        const { data, error } = await admin.from(table!).update(payload).match(match ?? {}).select();
        if (error) throw error;
        return json({ data });
      }
      case "delete": {
        const { data, error } = await admin.from(table!).delete().match(match ?? {}).select();
        if (error) throw error;
        return json({ data });
      }

      // ---------- RPC ----------
      case "rpc": {
        const { data, error } = await (admin.rpc as any)(rpc!, payload ?? {});
        if (error) throw error;
        return json({ data });
      }

      // ---------- Storage ----------
      case "storage.list": {
        const { data, error } = await admin.storage.from(bucket!).list(path ?? "", options ?? {});
        if (error) throw error;
        return json({ data });
      }
      case "storage.put": {
        // payload = { contentBase64: string, contentType?: string }
        const b64 = payload?.contentBase64;
        if (!b64) return json({ error: "contentBase64 required" }, 400);
        const bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
        const { data, error } = await admin.storage.from(bucket!).upload(path!, bytes, {
          contentType: payload?.contentType ?? "application/octet-stream",
          upsert: true,
        });
        if (error) throw error;
        return json({ data });
      }
      case "storage.get": {
        const { data, error } = await admin.storage.from(bucket!).createSignedUrl(path!, 600);
        if (error) throw error;
        return json({ url: data?.signedUrl });
      }
      case "storage.remove": {
        const { data, error } = await admin.storage.from(bucket!).remove([path!]);
        if (error) throw error;
        return json({ data });
      }

      // ---------- Auth (admin endpoints) ----------
      case "auth.invite": {
        const res = await fetch(`${SUPABASE_URL}/auth/v1/invite`, {
          method: "POST",
          headers: {
            apikey: SERVICE_KEY,
            authorization: `Bearer ${SERVICE_KEY}`,
            "content-type": "application/json",
          },
          body: JSON.stringify({ email: payload?.email, data: payload?.user_metadata ?? {} }),
        });
        if (!res.ok) throw new Error(await res.text());
        return json({ ok: true });
      }
      case "auth.list": {
        const res = await fetch(`${SUPABASE_URL}/auth/v1/admin/users`, {
          headers: { apikey: SERVICE_KEY, authorization: `Bearer ${SERVICE_KEY}` },
        });
        return new Response(res.body, { headers: { "content-type": "application/json", ...cors } });
      }

      default:
        return json({ error: "Unknown action" }, 400);
    }
  } catch (e: any) {
    return json({ error: e?.message ?? "Internal error" }, 500);
  }
});