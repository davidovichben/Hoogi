import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { crypto } from 'https://deno.land/std@0.224.0/crypto/mod.ts';

const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);

function uuidv4() {
  const b = new Uint8Array(16); crypto.getRandomValues(b);
  b[6]=(b[6]&0x0f)|0x40; b[8]=(b[8]&0x3f)|0x80;
  const h=[...b].map(x=>x.toString(16).padStart(2,'0')).join('');
  return `${h.slice(0,8)}-${h.slice(8,12)}-${h.slice(12,16)}-${h.slice(16,20)}-${h.slice(20)}`;
}

serve(async (req) => {
  try {
    const { questionnaire_id, filename } = await req.json();
    if (!questionnaire_id || !filename) return new Response('missing args', { status: 400 });

    const path = `${questionnaire_id}/${uuidv4()}-${filename}`;
    const { data, error } = await supabase.storage
      .from('questionnaire-uploads')
      .createSignedUploadUrl(path, 60);
    if (error) throw error;

    return new Response(JSON.stringify({ path, signedUrl: data.signedUrl, token: data.token }), {
      status: 200, headers: { 'Content-Type':'application/json' }
    });
  } catch (e) {
    console.error(e);
    return new Response('error', { status: 500 });
  }
});
