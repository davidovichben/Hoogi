-- Add onboarding_completed_at column to profiles table
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'onboarding_completed_at') THEN
        ALTER TABLE public.profiles ADD COLUMN onboarding_completed_at TIMESTAMPTZ;
        RAISE NOTICE 'Added onboarding_completed_at column to profiles table.';
    END IF;
END $$;

