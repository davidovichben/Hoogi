-- Add is_profile_complete column to profiles table
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'is_profile_complete') THEN
        ALTER TABLE public.profiles ADD COLUMN is_profile_complete BOOLEAN DEFAULT FALSE;
        RAISE NOTICE 'Added is_profile_complete column to profiles table.';
    END IF;
END $$;

