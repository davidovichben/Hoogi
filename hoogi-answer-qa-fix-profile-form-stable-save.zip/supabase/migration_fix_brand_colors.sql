-- ===== A. סכימה תקינה =====
-- A1) עמודה חסרה? נוסיף.
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS brand_accent text;

-- A2) נבטל מגבלה ישנה כדי שלא ניפול על דאטה קיים.
ALTER TABLE public.profiles
  DROP CONSTRAINT IF EXISTS profiles_brand_hex_chk;

-- A3) ניצור CHECK חדש, אבל NOT VALID (לא מאמתים עדיין).
ALTER TABLE public.profiles
  ADD CONSTRAINT profiles_brand_hex_chk
  CHECK (
    (brand_primary   ~ '^#[0-9A-Fa-f]{6}$' OR brand_primary   IS NULL) AND
    (brand_secondary ~ '^#[0-9A-Fa-f]{6}$' OR brand_secondary IS NULL) AND
    (brand_accent    ~ '^#[0-9A-Fa-f]{6}$' OR brand_accent    IS NULL)
  ) NOT VALID;

-- ===== B. נרמול נתונים קיימים =====
UPDATE public.profiles
SET
  brand_primary = CASE
    WHEN brand_primary IS NULL                 THEN brand_primary
    WHEN brand_primary ~ '^#[0-9A-Fa-f]{6}$'   THEN lower(brand_primary)
    WHEN brand_primary ~ '^[0-9A-Fa-f]{6}$'    THEN '#' || lower(brand_primary)
    ELSE '#1ea941'
  END,
  brand_secondary = CASE
    WHEN brand_secondary IS NULL               THEN brand_secondary
    WHEN brand_secondary ~ '^#[0-9A-Fa-f]{6}$' THEN lower(brand_secondary)
    WHEN brand_secondary ~ '^[0-9A-Fa-f]{6}$'  THEN '#' || lower(brand_secondary)
    ELSE '#9bb365'
  END,
  brand_accent = CASE
    WHEN brand_accent IS NULL                  THEN brand_accent
    WHEN brand_accent ~ '^#[0-9A-Fa-f]{6}$'    THEN lower(brand_accent)
    WHEN brand_accent ~ '^[0-9A-Fa-f]{6}$'     THEN '#' || lower(brand_accent)
    ELSE '#352b69'
  END;

-- ===== C. עכשיו מאמתים את המגבלה =====
ALTER TABLE public.profiles
  VALIDATE CONSTRAINT profiles_brand_hex_chk;

-- ===== D. (רשות) ברירות מחדל קדימה =====
ALTER TABLE public.profiles
  ALTER COLUMN brand_primary   SET DEFAULT '#1ea941',
  ALTER COLUMN brand_secondary SET DEFAULT '#9bb365',
  ALTER COLUMN brand_accent    SET DEFAULT '#352b69';
