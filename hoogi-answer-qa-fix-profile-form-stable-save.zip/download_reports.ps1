$URL   = 'https://lcazbaggfdejukjgkpeu.supabase.co/functions/v1/admin_gateway'
$TOKEN = 'd21bcca0-365e-4d7d-8f50-12805dbf6249511820d0b32f4936'
$headers = @{ Authorization = "Bearer $TOKEN"; "Content-Type" = "application/json" }

# מבנה בלבד
Write-Host "Downloading structure inventory..."
$bodyInv = '{"action":"rpc","rpc":"export_structure_inventory"}'
try {
    Invoke-WebRequest -Uri $URL -Method POST -Headers $headers -Body $bodyInv -OutFile "structure_inventory.json"
    Write-Host "✅ Structure inventory saved to structure_inventory.json"
} catch {
    Write-Host "❌ Error downloading structure inventory: $($_.Exception.Message)"
}

# RLS בלבד
Write-Host "Downloading RLS policies..."
$bodyRls = '{"action":"rpc","rpc":"export_rls_only"}'
try {
    Invoke-WebRequest -Uri $URL -Method POST -Headers $headers -Body $bodyRls -OutFile "rls_policies.json"
    Write-Host "✅ RLS policies saved to rls_policies.json"
} catch {
    Write-Host "❌ Error downloading RLS policies: $($_.Exception.Message)"
}



