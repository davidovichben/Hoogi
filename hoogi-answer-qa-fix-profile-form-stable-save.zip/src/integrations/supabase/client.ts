// Re-export from the main supabase client to prevent duplication
export { supabase } from '../../lib/supabaseClient';