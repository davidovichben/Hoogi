import { useEffect, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { supabase } from "@/lib/supabaseClient";

export function useProfileCompletionGuard() {
  const nav = useNavigate();
  const loc = useLocation();
  const ranRef = useRef(false);

  // עקיפה בזמן פיתוח
  if (import.meta.env.VITE_BYPASS_PROFILE_GUARD === "true") return;

  useEffect(() => {
    if (ranRef.current) return;
    ranRef.current = true;

    const pathname = loc.pathname;
    const inBuilder = /^\/(questionnaires|leads|responses)/.test(pathname);
    const inProfile = pathname.startsWith('/profile');

    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: p } = await supabase
        .from('profiles')
        .select('business_name, industry')
        .eq('id', user.id)
        .maybeSingle();

      const incomplete = !p?.business_name || !p?.industry;
      if (incomplete && !inProfile) {
        nav('/profile', { replace: true });
      }
    })();
  }, [loc.pathname, nav]);
}