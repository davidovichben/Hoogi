export const BRAND_DEFAULTS = {
  primary:   '#1ea941',
  secondary: '#9bb365',
  accent:    '#352b69',
} as const;




