// src/utils/brandColors.ts

// מנרמל ל-#RRGGBB או מחזיר undefined אם לא חוקי
export function normalizeHex6(input?: string | null): string | undefined {
  if (input == null) return undefined;
  let s = String(input).trim();
  if (s === "") return undefined;

  // מסיר # אם יש
  if (s.startsWith("#")) s = s.slice(1);

  // מרחיב 3 ספרות ל-6 (abc -> aabbcc)
  if (s.length === 3 && /^[0-9A-Fa-f]{3}$/.test(s)) {
    s = s.split("").map((c) => c + c).join("");
  }

  // בודק תקינות (6 ספרות הקסדצימליות)
  if (!/^[0-9A-Fa-f]{6}$/.test(s)) return undefined;

  return ("#" + s).toLowerCase();
}

// זורק מפתחות ריקים; מחזיר רק שדות צבע חוקיים
export function sanitizeBrandColors(colors: {
  brand_primary?: string | null;
  brand_secondary?: string | null;
  brand_accent?: string | null;
}) {
  const primary   = normalizeHex6(colors.brand_primary);
  const secondary = normalizeHex6(colors.brand_secondary);
  const accent    = normalizeHex6(colors.brand_accent);

  return {
    ...(primary   && { brand_primary:   primary }),
    ...(secondary && { brand_secondary: secondary }),
    ...(accent    && { brand_accent:    accent }),
  };
}

