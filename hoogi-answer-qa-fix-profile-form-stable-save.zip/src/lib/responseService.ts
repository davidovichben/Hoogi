import { supabase } from './supabaseClient';
import { uploadFileToQuestionnaire } from './uploadService';

export interface ResponseData {
  questionnaire_id: string;
  respondent_contact: {
    name?: string;
    email?: string;
    phone?: string;
  };
  answers: Record<string, any>;
  attachments?: string[]; // Array of file paths
  meta?: Record<string, any>;
  status?: string;
  rating?: number;
}

export interface ResponseWithFiles extends ResponseData {
  files?: File[]; // Files to upload
}

/**
 * שולח תשובה לשאלון עם תמיכה בהעלאת קבצים
 */
export async function submitResponseWithFiles(responseData: ResponseWithFiles): Promise<string> {
  const { files, ...responsePayload } = responseData;
  
  // 1. העלאת קבצים אם קיימים
  let attachments: string[] = [];
  if (files && files.length > 0) {
    const uploadPromises = files.map(file => 
      uploadFileToQuestionnaire(responseData.questionnaire_id, file)
    );
    attachments = await Promise.all(uploadPromises);
  }

  // 2. הכנת payload עם קבצים
  const finalPayload: ResponseData = {
    ...responsePayload,
    attachments: [...(responsePayload.attachments || []), ...attachments]
  };

  // 3. שליחה ל-DB
  const { data, error } = await supabase
    .from('responses')
    .insert(finalPayload)
    .select('id')
    .single();

  if (error) {
    throw new Error(`Failed to submit response: ${error.message}`);
  }

  return data.id;
}

/**
 * שולח תשובה רגילה (ללא קבצים)
 */
export async function submitResponse(responseData: ResponseData): Promise<string> {
  const { data, error } = await supabase
    .from('responses')
    .insert(responseData)
    .select('id')
    .single();

  if (error) {
    throw new Error(`Failed to submit response: ${error.message}`);
  }

  return data.id;
}

/**
 * מקבל תשובות עם פרטים מלאים
 */
export async function getResponses(questionnaireId?: string): Promise<any[]> {
  let query = supabase
    .from('responses_flat_v3')
    .select('*')
    .order('submitted_at', { ascending: false });

  if (questionnaireId) {
    query = query.eq('questionnaire_id', questionnaireId);
  }

  const { data, error } = await query;

  if (error) {
    throw new Error(`Failed to fetch responses: ${error.message}`);
  }

  return data || [];
}

/**
 * מקבל תשובה ספציפית לפי ID
 */
export async function getResponseById(responseId: string): Promise<any> {
  const { data, error } = await supabase
    .from('responses_flat_v3')
    .select('*')
    .eq('response_id', responseId)
    .single();

  if (error) {
    throw new Error(`Failed to fetch response: ${error.message}`);
  }

  return data;
}

/**
 * מעדכן סטטוס תשובה
 */
export async function updateResponseStatus(responseId: string, status: string): Promise<void> {
  const { error } = await supabase
    .from('responses')
    .update({ status })
    .eq('id', responseId);

  if (error) {
    throw new Error(`Failed to update response status: ${error.message}`);
  }
}

/**
 * מוחק תשובה
 */
export async function deleteResponse(responseId: string): Promise<void> {
  const { error } = await supabase
    .from('responses')
    .delete()
    .eq('id', responseId);

  if (error) {
    throw new Error(`Failed to delete response: ${error.message}`);
  }
}






