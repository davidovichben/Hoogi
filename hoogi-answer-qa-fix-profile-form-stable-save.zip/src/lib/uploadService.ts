import { supabase } from './supabaseClient';

export interface UploadResponse {
  path: string;
  signedUrl: string;
  token: string;
}

export interface DownloadResponse {
  url: string;
}

/**
 * מקבל Signed Upload URL מ-Edge Function
 */
export async function getUploadUrl(questionnaireId: string, filename: string): Promise<UploadResponse> {
  const { data, error } = await supabase.functions.invoke('get-upload-url', {
    body: { questionnaire_id: questionnaireId, filename }
  });

  if (error) {
    throw new Error(`Failed to get upload URL: ${error.message}`);
  }

  return data;
}

/**
 * מעלה קובץ ל-Supabase Storage באמצעות Signed URL
 */
export async function uploadFile(signedUrl: string, file: File): Promise<void> {
  const response = await fetch(signedUrl, {
    method: 'PUT',
    body: file,
    headers: {
      'Content-Type': file.type,
    },
  });

  if (!response.ok) {
    throw new Error(`Upload failed: ${response.statusText}`);
  }
}

/**
 * זרימה מלאה: קבלת URL + העלאה
 */
export async function uploadFileToQuestionnaire(
  questionnaireId: string, 
  file: File
): Promise<string> {
  // 1. קבלת Signed Upload URL
  const { path, signedUrl } = await getUploadUrl(questionnaireId, file.name);
  
  // 2. העלאת הקובץ
  await uploadFile(signedUrl, file);
  
  // 3. החזרת ה-path לשמירה ב-DB
  return path;
}

/**
 * מקבל Signed Download URL מ-Edge Function
 */
export async function getDownloadUrl(path: string, expiresIn: number = 300): Promise<DownloadResponse> {
  const { data, error } = await supabase.functions.invoke('sign-download-url', {
    body: { path, expiresIn }
  });

  if (error) {
    throw new Error(`Failed to get download URL: ${error.message}`);
  }

  return data;
}

/**
 * פותח קובץ להורדה בלשונית חדשה
 */
export async function downloadFile(path: string): Promise<void> {
  const { url } = await getDownloadUrl(path);
  window.open(url, '_blank');
}

/**
 * מחזיר URL להורדה (לשימוש ב-<a> tags)
 */
export async function getFileDownloadUrl(path: string): Promise<string> {
  const { url } = await getDownloadUrl(path);
  return url;
}






