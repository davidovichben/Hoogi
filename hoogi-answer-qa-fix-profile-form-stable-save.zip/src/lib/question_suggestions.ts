// src/lib/question_suggestions.ts
import { TEMPLATES, FALLBACK, type TemplateDict } from "@/data/question_templates";
import { supabase } from "@/integrations/supabase/client";

export type SourceRow = {
  id: string;
  user_id: string;
  kind: string;         // website/facebook/instagram/linkedin/youtube/pdf/other
  url?: string | null;
  title?: string | null;
  file_path?: string | null;
};

export type ProfileLike = {
  business_name?: string | null;
  occupation?: string | null;
  suboccupation?: string | null;
};

function mapOccToCategory(occ?: string | null): keyof TemplateDict | null {
  const x = (occ || "").toLowerCase();
  if (!x) return null;
  if (/(עו.?ד|עורכי.?דין|legal|law)/i.test(x)) return "lawyer";
  if (/(חשב|ראיית.?חשבון|account|cpa)/i.test(x)) return "accountant";
  if (/(ביטוח|insurance)/i.test(x)) return "insurance";
  if (/(יועץ|ייעוץ|consultant|consulting)/i.test(x)) return "consultant";
  if (/(מטפל|טיפול|therapist|therapy|פסיכולוג|psychologist)/i.test(x)) return "therapist";
  if (/(נדל.?ן|real.?estate|תיווך|יזום)/i.test(x)) return "real_estate";
  return null;
}

function isOther(v?: string | null) {
  const x = (v || "").toLowerCase().trim();
  return !x || x === "other" || x === "אחר";
}

function hostOf(url = "") {
  try { return new URL(url).hostname.replace(/^www\./, ""); } catch { return ""; }
}

function uniq(arr: string[]) {
  const s = new Set<string>(); const out: string[] = [];
  for (const t of arr) { const k = t.trim(); if (k && !s.has(k)) { s.add(k); out.push(k); } }
  return out;
}

function personalize(profile: ProfileLike, sources: SourceRow[]): string[] {
  const out: string[] = [];
  const name = (profile.business_name || "").trim();
  const sub = (profile.suboccupation || "").trim();
  const occ = (profile.occupation || "").trim();

  const hosts = uniq(sources.map(s => hostOf(s.url || "")).filter(Boolean)).slice(0, 4);
  const titles = sources.map(s => (s.title || "").trim()).filter(Boolean).slice(0, 3);

  if (name) {
    out.push(`מה הערך הייחודי של "${name}" שכדאי להדגיש בתחילת הטופס?`);
  }
  if (sub) {
    out.push(`בתת־התחום "${sub}", אילו שאלות יסייעו לסנן פניות לא רלוונטיות?`);
  } else if (occ) {
    out.push(`בתחום "${occ}", מה השאלה הראשונה שתסייע לסיווג נכון של הפנייה?`);
  }
  if (hosts.length) out.push(`להסתמך על תוכן מ: ${hosts.join(", ")} — אילו שאלות כדאי לשאול?`);
  for (const t of titles) out.push(`בהתאם ל"${t}" — איזו שאלה תחזק את המסר?`);

  return uniq(out);
}

function baseTemplates(profile: ProfileLike): string[] {
  const cat = mapOccToCategory(profile.occupation);
  if (!cat) return [];
  const dict = TEMPLATES[cat] || {};
  const sub = (profile.suboccupation || "").trim();
  return (sub && dict[sub]) || dict["_default"] || [];
}

// ====== נתיב ללא AI (תמיד קיים) ======
export function getSuggestedQuestionsLocal(opts: { profile: ProfileLike; sources: SourceRow[]; limit?: number; }): string[] {
  const { profile, sources, limit = 5 } = opts;
  if (isOther(profile.occupation) || isOther(profile.suboccupation)) return [];
  let out = uniq([...personalize(profile, sources), ...baseTemplates(profile)]);
  if (out.length < limit) out = uniq([...out, ...FALLBACK]);
  return out.slice(0, limit);
}

// ====== נתיב עם AI (אופציונלי) ======
export async function getSuggestedQuestionsAI(opts: {
  profile: ProfileLike; sources: SourceRow[]; limit?: number; language?: "he"|"en"|"fr";
}): Promise<string[]> {
  const { profile, sources, limit = 5, language = "he" } = opts;
  const payload = {
    businessName: profile.business_name || "",
    occupation: profile.occupation || "",
    suboccupation: profile.suboccupation || "",
    category: mapOccToCategory(profile.occupation),
    sources: sources.slice(0, 6).map(s => ({ kind: s.kind, url: s.url, title: s.title, file_path: s.file_path })),
    language,
    max: Math.min(Math.max(limit, 2), 6)
  };

  try {
    const { data, error } = await supabase.functions.invoke("suggest-questions", {
      body: payload,
    });
    if (error) throw error;
    const items = data;
    const arr: string[] = Array.isArray(items)
      ? items.map((it: any) => (typeof it === "string" ? it : it?.title)).filter(Boolean)
      : [];
    if (arr.length) return arr.slice(0, limit);
  } catch {
    // ניפול ללוקלי אם ה-AI לא זמין
  }
  return getSuggestedQuestionsLocal({ profile, sources, limit });
}