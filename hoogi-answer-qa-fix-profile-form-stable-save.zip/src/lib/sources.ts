// src/lib/sources.ts
import { supabase } from "@/integrations/supabase/client";

const BUCKET = "client-sources";

export type SourceKind =
  | "website" | "facebook" | "instagram" | "linkedin" | "youtube"
  | "pdf" | "other";

/** מביא UID ישירות מסופאבייס (ללא תלות ב-getUserId פנימי) */
async function getUid(): Promise<string> {
  const { data, error } = await supabase.auth.getUser();
  if (error) throw error;
  const uid = data?.user?.id;
  if (!uid) throw new Error("משתמש לא מזוהה");
  return uid;
}

/** נרמול kind לערכים שמותרים בבסיס הנתונים (לפי ה-CHECK הקיים) */
function normalizeKind(k: string): SourceKind {
  const x = (k || "").toLowerCase();
  if (["website", "site", "web", "אתר", "קישור"].includes(x)) return "website";
  if (["facebook", "fb", "פייסבוק"].includes(x)) return "facebook";
  if (["instagram", "ig", "אינסטגרם"].includes(x)) return "instagram";
  if (["linkedin", "li", "לינקדאין"].includes(x)) return "linkedin";
  if (["youtube", "yt", "יוטיוב"].includes(x)) return "youtube";
  if (["pdf", "document", "מסמך"].includes(x)) return "pdf";
  // כל היתר ימופו ל-other כדי לא ליפול על CHECK (למשל 'tiktok')
  return "other";
}

/** מוסיף https:// אם חסר ובודק שה-URL תקין */
function normalizeUrl(input: string): string {
  let u = (input || "").trim();
  if (!/^https?:\/\//i.test(u)) u = "https://" + u;
  // ייזרק אם לא תקין — נתפוס למעלה וניתן הודעה
  // eslint-disable-next-line no-new
  new URL(u);
  return u;
}

/** שם קובץ בטוח (ללא השם המקורי כדי להימנע מ-Invalid key) */
function makeSafePdfKey(userId: string) {
  return `${userId}/${Date.now()}-${crypto.randomUUID()}.pdf`;
}

/** שליפת כל המקורות של המשתמש */
export async function listSources() {
  const uid = await getUid();
  const { data, error } = await supabase
    .from("profile_sources")
    .select("*")
    .eq("user_id", uid)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return data ?? [];
}

/** הוספת קישור */
export async function addLink(kind: string, url: string, title?: string) {
  const uid = await getUid();
  const safeKind = normalizeKind(kind);
  const safeUrl = normalizeUrl(url);

  const { data, error } = await supabase
    .from("profile_sources")
    .insert({
      user_id: uid,
      kind: safeKind,
      url: safeUrl,
      title: (title || "").trim() || null,
    })
    .select("*")
    .single();

  if (error) throw error;
  return data;
}

/** העלאת PDF + רישום בטבלה */
export async function uploadPdf(file: File, title?: string) {
  const uid = await getUid();
  if (!(file?.type || "").toLowerCase().includes("pdf")) {
    throw new Error("נא להעלות קובץ PDF בלבד");
  }

  const key = makeSafePdfKey(uid);

  const { error: upErr } = await supabase
    .storage.from(BUCKET)
    .upload(key, file, {
      upsert: true,
      cacheControl: "3600",
      contentType: "application/pdf",
    });
  if (upErr) throw upErr;

  const { data, error } = await supabase
    .from("profile_sources")
    .insert({
      user_id: uid,
      kind: "pdf",
      file_path: key,
      title: (title || file.name || "מסמך").toString(),
    })
    .select("*")
    .single();

  if (error) throw error;
  return data;
}

/** מחיקת מקור + מחיקת קובץ אם יש */
export async function removeSource(id: string) {
  const { data, error } = await supabase
    .from("profile_sources")
    .delete()
    .eq("id", id)
    .select("*")
    .single();
  if (error) throw error;

  if (data?.file_path) {
    await supabase.storage.from(BUCKET).remove([data.file_path]);
  }
  return true;
}

/** קבלת URL ציבורי לקובץ בדלי public */
export function publicUrl(file_path: string) {
  return supabase.storage.from(BUCKET).getPublicUrl(file_path).data.publicUrl;
}