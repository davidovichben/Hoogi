import { supabase } from './supabaseClient';
import { uploadFileToQuestionnaire } from './uploadService';

export interface LeadData {
  questionnaire_id: string;
  respondent_contact: {
    name?: string;
    email?: string;
    phone?: string;
  };
  answers: Record<string, any>;
  attachments?: string[]; // Array of file paths
  meta?: Record<string, any>;
  status?: string;
  rating?: number;
  channel?: string;
  ref?: string;
}

export interface LeadWithFiles extends LeadData {
  files?: File[]; // Files to upload
}

/**
 * יוצר ליד עם תמיכה בהעלאת קבצים
 */
export async function createLeadWithFiles(leadData: LeadWithFiles): Promise<string> {
  const { files, ...leadPayload } = leadData;
  
  // 1. העלאת קבצים אם קיימים
  let attachments: string[] = [];
  if (files && files.length > 0) {
    const uploadPromises = files.map(file => 
      uploadFileToQuestionnaire(leadData.questionnaire_id, file)
    );
    attachments = await Promise.all(uploadPromises);
  }

  // 2. הכנת payload עם קבצים
  const finalPayload: LeadData = {
    ...leadPayload,
    attachments: [...(leadPayload.attachments || []), ...attachments]
  };

  // 3. יצירת ליד
  const { data, error } = await supabase
    .from('leads')
    .insert(finalPayload)
    .select('id')
    .single();

  if (error) {
    throw new Error(`Failed to create lead: ${error.message}`);
  }

  return data.id;
}

/**
 * יוצר ליד רגיל (ללא קבצים)
 */
export async function createLead(leadData: LeadData): Promise<string> {
  const { data, error } = await supabase
    .from('leads')
    .insert(leadData)
    .select('id')
    .single();

  if (error) {
    throw new Error(`Failed to create lead: ${error.message}`);
  }

  return data.id;
}

/**
 * מקבל לידים עם פרטים מלאים
 */
export async function getLeads(questionnaireId?: string): Promise<any[]> {
  let query = supabase
    .from('leads_flat_v3')
    .select('*')
    .order('created_at', { ascending: false });

  if (questionnaireId) {
    query = query.eq('questionnaire_id', questionnaireId);
  }

  const { data, error } = await query;

  if (error) {
    throw new Error(`Failed to fetch leads: ${error.message}`);
  }

  return data || [];
}

/**
 * מקבל ליד ספציפי לפי ID
 */
export async function getLeadById(leadId: string): Promise<any> {
  const { data, error } = await supabase
    .from('leads_flat_v3')
    .select('*')
    .eq('lead_id', leadId)
    .single();

  if (error) {
    throw new Error(`Failed to fetch lead: ${error.message}`);
  }

  return data;
}

/**
 * מעדכן סטטוס ליד
 */
export async function updateLeadStatus(leadId: string, status: string): Promise<void> {
  const { error } = await supabase
    .from('leads')
    .update({ status })
    .eq('id', leadId);

  if (error) {
    throw new Error(`Failed to update lead status: ${error.message}`);
  }
}

/**
 * מוחק ליד
 */
export async function deleteLead(leadId: string): Promise<void> {
  const { error } = await supabase
    .from('leads')
    .delete()
    .eq('id', leadId);

  if (error) {
    throw new Error(`Failed to delete lead: ${error.message}`);
  }
}

/**
 * מקבל לידים לפי ערוץ
 */
export async function getLeadsByChannel(channel: string): Promise<any[]> {
  const { data, error } = await supabase
    .from('leads_flat_v3')
    .select('*')
    .eq('channel', channel)
    .order('created_at', { ascending: false });

  if (error) {
    throw new Error(`Failed to fetch leads by channel: ${error.message}`);
  }

  return data || [];
}






