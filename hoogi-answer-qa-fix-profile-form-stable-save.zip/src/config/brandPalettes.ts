export const BRAND_DEFAULTS = {
  primary:   '#0ea5a5',
  secondary: '#14b8a6',
  background:'#ffffff',
};

export const BRAND_PALETTES = [
  { name: 'Teal',   primary:'#0ea5a5', secondary:'#14b8a6', background:'#ffffff' },
  { name: 'Indigo', primary:'#4f46e5', secondary:'#6366f1', background:'#ffffff' },
  { name: 'Purple', primary:'#7c3aed', secondary:'#a78bfa', background:'#ffffff' },
  { name: 'Emerald',primary:'#10b981', secondary:'#34d399', background:'#ffffff' },
  { name: 'Slate',  primary:'#334155', secondary:'#475569', background:'#ffffff' },
];

export const HEX_OK = /^#[0-9a-fA-F]{6}$/;

export const coerceTriplet = (p?:string|null,s?:string|null,bg?:string|null) => ({
  primary:   (p  && HEX_OK.test(p))  ? p.toLowerCase()  : BRAND_DEFAULTS.primary,
  secondary: (s  && HEX_OK.test(s))  ? s.toLowerCase()  : BRAND_DEFAULTS.secondary,
  background:(bg && HEX_OK.test(bg)) ? bg.toLowerCase() : BRAND_DEFAULTS.background,
});
