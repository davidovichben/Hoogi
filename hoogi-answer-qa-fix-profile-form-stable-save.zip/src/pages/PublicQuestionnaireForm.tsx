/* === PublicQuestionnaireForm.tsx ===
   הדבק ל- src/pages/PublicQuestionnaireForm.tsx
   טופס ציבורי מינימלי (שם, אימייל, טלפון + העלאת קובץ אופציונלית)
   טוען שאלון לפי :id (יכול להיות questionnaire_id או token אם יש לך עמודה כזו)
   שולח INSERT ל-public.responses עם answers לא-ריק כדי לעבור את ה- NOT NULL
*/
import React, { useMemo, useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL!,
  import.meta.env.VITE_SUPABASE_ANON_KEY!
);

// חתימה ל-Edge Function
async function callEdge(path: string, body?: any) {
  const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/${path}`;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      "Content-Type": "application/json",
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) {
    const t = await res.text();
    throw new Error(t || `Edge ${path} failed`);
  }
  return res.json().catch(() => ({}));
}

type Questionnaire = {
  id: string;
  owner_id?: string | null;
  title?: string | null;
  brand_primary?: string | null;
  brand_secondary?: string | null;
  brand_logo_path?: string | null;
  meta?: any;
};

export default function PublicQuestionnaireForm() {
  const { id } = useParams(); // :id יכול להיות UUID של השאלון (או token אם יש עמודה token)
  const [q, setQ] = useState<Questionnaire | null>(null);
  const [loading, setLoading] = useState(true);
  const [sent, setSent] = useState<{ok:boolean; id?:string; error?:string}|null>(null);

  // שדות בסיסיים לטופס
  const [fullName, setFullName] = useState("");
  const [email, setEmail]   = useState("");
  const [phone, setPhone]   = useState("");
  const [file, setFile]     = useState<File | null>(null);
  const [uploadedPath, setUploadedPath] = useState<string | null>(null);

  // טוען את השאלון לפי id או token
  useEffect(() => {
    (async () => {
      try {
        if (!id) throw new Error("Missing questionnaire id");
        // מנסה לפי id ישיר; אם יש אצלך עמודת token - אפשר להחליף לאו-ר
        const { data, error } = await supabase
          .from("questionnaires")
          .select("id, owner_id, title, brand_primary, brand_secondary, brand_logo_path, meta")
          .or(`id.eq.${id},token.eq.${id}`)
          .maybeSingle();

        if (error) throw error;
        if (!data) throw new Error("Questionnaire not found");
        setQ(data as Questionnaire);
      } catch (e:any) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    })();
  }, [id]);

  // העלאת קובץ (אופציונלי) דרך Edge get-upload-url
  async function handleUpload() {
    if (!file || !q) return null;
    const ext = file.name.split(".").pop() || "bin";
    const { putUrl, path } = await callEdge("get-upload-url", {
      questionnaire_id: q.id,
      filename: `answer-${Date.now()}.${ext}`,
      content_type: file.type || "application/octet-stream",
    });
    const putRes = await fetch(putUrl, { method: "PUT", body: file });
    if (!putRes.ok) throw new Error("Upload failed");
    setUploadedPath(path);
    return path as string;
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    try {
      if (!q) throw new Error("Questionnaire not loaded");

      let attachmentPath: string | null = null;
      if (file) {
        attachmentPath = await handleUpload();
      }

      // answers לעולם לא ריק (NOT NULL) — שומר לפחות אובייקט בסיסי
      const answers = {
        fields: {
          full_name: fullName || null,
          email: email || null,
          phone: phone || null,
        },
        attachments: attachmentPath ? [attachmentPath] : [],
      };

      const meta = {
        channel: "public",
        submitted_at: new Date().toISOString(),
        owner_id: q.owner_id ?? null,
        source_page: window.location.href,
      };

      const respondent_contact = {
        name: fullName || null,
        email: email || null,
        phone: phone || null,
      };

      const { data, error } = await supabase
        .from("responses")
        .insert({
          questionnaire_id: q.id,
          status: "submitted",
          respondent_contact,
          answers,        // חשוב: לא ריק
          meta,           // כולל submitted_at
        })
        .select("id")
        .single();

      if (error) throw error;

      // compose-auto-reply ירוץ ע"י ה-Webhook (INSERT על responses)
      setSent({ ok: true, id: data?.id });
    } catch (err:any) {
      console.error(err);
      setSent({ ok:false, error: String(err.message || err) });
    }
  }

  const brandStyle = useMemo(() => {
    return {
      borderTop: `6px solid ${q?.brand_primary || "#4b5563"}`,
    } as React.CSSProperties;
  }, [q]);

  if (loading) return <div style={{padding:24}}>טוען…</div>;
  if (!q)      return <div style={{padding:24}}>השאלון לא נמצא</div>;

  if (sent?.ok) {
    return (
      <div dir="rtl" style={{maxWidth:520, margin:"40px auto", padding:24, border:"1px solid #e5e7eb", borderRadius:12}}>
        <h2 style={{marginTop:0}}>תודה! הטופס נשלח</h2>
        <p>קיבלנו את פנייתך ונחזור אליך בהקדם.</p>
        <div style={{fontSize:12, color:"#6b7280"}}>מס׳ אישור: {sent.id}</div>
      </div>
    );
  }

  return (
    <div dir="rtl" style={{maxWidth:520, margin:"40px auto", padding:24, border:"1px solid #e5e7eb", borderRadius:12, ...brandStyle}}>
      <h2 style={{marginTop:0}}>{q.title || "השארת פרטים"}</h2>
      <form onSubmit={onSubmit}>
        <div style={{display:"grid", gap:12}}>
          <label>
            שם מלא
            <input value={fullName} onChange={e=>setFullName(e.target.value)} required
                   style={{width:"100%", padding:10, border:"1px solid #d1d5db", borderRadius:8}} />
          </label>
          <label>
            אימייל
            <input type="email" value={email} onChange={e=>setEmail(e.target.value)} required
                   style={{width:"100%", padding:10, border:"1px solid #d1d5db", borderRadius:8}} />
          </label>
          <label>
            נייד
            <input value={phone} onChange={e=>setPhone(e.target.value)}
                   style={{width:"100%", padding:10, border:"1px solid #d1d5db", borderRadius:8}} />
          </label>

          <label>
            קובץ (אופציונלי)
            <input type="file" onChange={e=>setFile(e.target.files?.[0] ?? null)} />
            {uploadedPath && <div style={{fontSize:12}}>הועלה: {uploadedPath}</div>}
          </label>

          <button type="submit" style={{padding:"10px 16px", border:"none", borderRadius:8, background:"#111827", color:"#fff"}}>
            שליחה
          </button>
        </div>
      </form>
    </div>
  );
}





