import { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/lib/supabaseClient";
import { getUploadUrl } from "@/lib/uploadService"; // משתמש בפונקציית Edge get-upload-url

type Question = {
  id: string;
  questionnaire_id: string;
  type: "text" | "email" | "number" | "textarea" | "select" | "radio" | "checkbox" | "date" | "file";
  label: string;
  required: boolean;
  order_index: number;
  options?: any;       // JSON
  validation?: any;    // JSON
  name?: string;       // נשתמש בו כ-key אם קיים
  key: string;         // תמיד קיים לאחר נרמול
};

export default function PublicQuestionnaire() {
  const { id } = useParams<{ id: string }>();
  const [loading, setLoading] = useState(true);
  const [qTitle, setQTitle] = useState<string>("");
  const [brand, setBrand] = useState<{ logo?: string; primary?: string; secondary?: string; bg?: string }>();
  const [questions, setQuestions] = useState<Question[]>([]);
  const [values, setValues] = useState<Record<string, any>>({});
  const [error, setError] = useState<string | null>(null);
  const [sent, setSent] = useState(false);

  useEffect(() => {
    (async () => {
      if (!id) return;
      setLoading(true);
      setError(null);
      try {
        // 1) שאלון
        const { data: q, error: qErr } = await supabase
          .from("questionnaires")
          .select("id, title, brand_logo_path, brand_primary, brand_secondary, brand_bg")
          .eq("id", id)
          .single();
        if (qErr) throw qErr;
        setQTitle(q?.title ?? "");
        setBrand({
          logo: q?.brand_logo_path ?? undefined,
          primary: q?.brand_primary ?? undefined,
          secondary: q?.brand_secondary ?? undefined,
          bg: q?.brand_bg ?? undefined,
        });

        // 2) שאלות
        const { data: rows, error: qnErr } = await supabase
          .from("questions")
          .select("id, questionnaire_id, label, type, required, order_index, options, validation")
          .eq("questionnaire_id", id)
          .order("order_index", { ascending: true });

        if (qnErr) throw qnErr;

        const KNOWN_KEYS: Record<string, string> = {
          "שם מלא": "full_name",
          "אימייל": "email",
          "מייל": "email",
          "טלפון": "phone",
          "איך נוכל לעזור?": "message",
        };

        const norm = (rows ?? []).map((r: any) => ({
          ...r,
          key: KNOWN_KEYS[(r.label || "").trim()] ?? String(r.id),
        })) as Question[];

        setQuestions(norm);

        // איפוס ערכים התחלתיים
        const init: Record<string, any> = {};
        norm.forEach((q) => (init[q.key] = q.type === "checkbox" ? [] : ""));
        setValues(init);
      } catch (e: any) {
        setError(e?.message || "שגיאה בטעינת הטופס");
      } finally {
        setLoading(false);
      }
    })();
  }, [id]);

  const onChange = (key: string, v: any) => setValues((prev) => ({ ...prev, [key]: v }));

  const respondent_contact = useMemo(() => {
    const name  = values["full_name"] || values["name"] || "";
    const email = values["email"] || "";
    const phone = values["phone"] || "";
    return { name, email, phone };
  }, [values]);

  const submit = async () => {
    try {
      setError(null);

      // ולידציה בסיסית לשדות חובה
      for (const q of questions) {
        const v = values[q.key];
        if (q.required) {
          if (q.type === "checkbox" && Array.isArray(v) && v.length === 0) {
            throw new Error(`יש להשלים: ${q.label}`);
          }
          if (!v) throw new Error(`יש להשלים: ${q.label}`);
        }
      }

      // לא נשמור תשובה ריקה לגמרי
      const nonEmpty = Object.values(values).some((v) => (Array.isArray(v) ? v.length > 0 : v && String(v).trim() !== ""));
      if (!nonEmpty) throw new Error("לא מולאו תשובות בטופס.");

      const payload = {
        questionnaire_id: id,
        answers: values,
        respondent_contact,
        status: "submitted",
        meta: {
          submitted_at: new Date().toISOString(),
          channel: "landing",
        },
      };

      const { error: insErr } = await supabase.from("responses").insert(payload);
      if (insErr) throw insErr;

      setSent(true);
    } catch (e: any) {
      setError(e?.message || "שמירה נכשלה");
    }
  };

  // העלאת קבצים
  const handleFile = async (key: string, file: File | null) => {
    if (!file || !id) return;
    try {
      const { path, signedUrl } = await getUploadUrl(id, file.name);
      await fetch(signedUrl, { method: "PUT", body: file });
      onChange(key, path); // נשמור את הנתיב בתשובה
    } catch (e: any) {
      setError("שגיאה בהעלאת הקובץ");
    }
  };

  if (loading)   return <div style={{padding:24}}>טוען…</div>;
  if (error)     return <div style={{padding:24, color:"crimson"}}>{error}</div>;
  if (sent)      return <div style={{padding:24}}>תודה! קיבלנו את פנייתך.</div>;
  if (!questions?.length) return <div style={{padding:24}}>אין שאלות להצגה. בדקי שהוספת ושמרת שאלות לשאלון.</div>;

  const brandStyles: React.CSSProperties = {
    background: brand?.bg || "transparent",
    color: brand?.primary || "inherit",
    minHeight: 24,
  };

  return (
    <div dir="rtl" style={{maxWidth: 880, margin: "24px auto", padding: 24, background:"#fff", borderRadius:16, boxShadow: "0 10px 30px rgba(0,0,0,.06)"}}>
      <div style={{display:"flex", alignItems:"center", gap:12, marginBottom:24}}>
        {brand?.logo && <img src={brand.logo} alt="logo" style={{width:48, height:48, borderRadius:8, objectFit:"contain"}}/>}
        <h2 style={{margin:0}}>{qTitle || "שאלון"}</h2>
      </div>

      <div style={{display:"grid", gap:16}}>
        {questions.map((q) => (
          <div key={q.id}>
            <label style={{display:"block", marginBottom:6}}>
              {q.label} {q.required ? "*" : ""}
            </label>

            {q.type === "text" || q.type === "email" || q.type === "number" ? (
              <input
                type={q.type === "text" ? "text" : q.type}
                value={values[q.key] || ""}
                onChange={(e) => onChange(q.key, e.target.value)}
                style={{width:"100%", padding:"10px 12px", border:"1px solid #e5e7eb", borderRadius:10}}
              />
            ) : q.type === "textarea" ? (
              <textarea
                value={values[q.key] || ""}
                onChange={(e) => onChange(q.key, e.target.value)}
                rows={4}
                style={{width:"100%", padding:"10px 12px", border:"1px solid #e5e7eb", borderRadius:10}}
              />
            ) : q.type === "select" ? (
              <select
                value={values[q.key] || ""}
                onChange={(e) => onChange(q.key, e.target.value)}
                style={{width:"100%", padding:"10px 12px", border:"1px solid #e5e7eb", borderRadius:10}}
              >
                <option value="">בחרי…</option>
                {(q.options?.choices ?? []).map((opt: any) => (
                  <option key={String(opt.value ?? opt)} value={opt.value ?? opt}>
                    {opt.label ?? opt}
                  </option>
                ))}
              </select>
            ) : q.type === "radio" ? (
              <div style={{display:"flex", gap:12, flexWrap:"wrap"}}>
                {(q.options?.choices ?? []).map((opt: any) => {
                  const val = opt.value ?? opt;
                  return (
                    <label key={String(val)} style={{display:"flex", alignItems:"center", gap:6}}>
                      <input
                        type="radio"
                        checked={values[q.key] === val}
                        onChange={() => onChange(q.key, val)}
                      />
                      {opt.label ?? opt}
                    </label>
                  );
                })}
              </div>
            ) : q.type === "checkbox" ? (
              <div style={{display:"flex", gap:12, flexWrap:"wrap"}}>
                {(q.options?.choices ?? []).map((opt: any) => {
                  const val = opt.value ?? opt;
                  const arr: any[] = values[q.key] || [];
                  const checked = arr.includes(val);
                  return (
                    <label key={String(val)} style={{display:"flex", alignItems:"center", gap:6}}>
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() => {
                          const next = checked ? arr.filter(v => v !== val) : [...arr, val];
                          onChange(q.key, next);
                        }}
                      />
                      {opt.label ?? opt}
                    </label>
                  );
                })}
              </div>
            ) : q.type === "date" ? (
              <input
                type="date"
                value={values[q.key] || ""}
                onChange={(e) => onChange(q.key, e.target.value)}
                style={{width:"100%", padding:"10px 12px", border:"1px solid #e5e7eb", borderRadius:10}}
              />
            ) : q.type === "file" ? (
              <input
                type="file"
                onChange={(e) => handleFile(q.key, e.target.files?.[0] ?? null)}
              />
            ) : (
              <input
                type="text"
                value={values[q.key] || ""}
                onChange={(e) => onChange(q.key, e.target.value)}
                style={{width:"100%", padding:"10px 12px", border:"1px solid #e5e7eb", borderRadius:10}}
              />
            )}
          </div>
        ))}
      </div>

      <div style={{display:"flex", justifyContent:"space-between", alignItems:"center", marginTop:24}}>
        <div style={{height:8, width:8, borderRadius:99, ...brandStyles}}/>
        <button
          onClick={submit}
          style={{padding:"10px 16px", borderRadius:10, background: brand?.primary || "#10b981", color:"#fff", border:"none"}}
        >
          שליחה
        </button>
      </div>

      {error && <div style={{marginTop:12, color:"crimson"}}>{error}</div>}
    </div>
  );
}