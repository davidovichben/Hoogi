import React, { useState } from 'react';
import { submitResponseWithFiles } from '@/lib/responseService';
import { Button } from './ui/button';
import { toast } from '@/hooks/use-toast';

interface PublicQuestionnaireFormProps {
  questionnaireId: string;
  questions: Array<{
    id: string;
    type: 'short_text' | 'long_text' | 'multiple_choice' | 'checkbox' | 'phone' | 'email' | 'file' | 'number' | 'date';
    title: string;
    required?: boolean;
    options?: string[];
    allow_voice_input?: boolean;
  }>;
  onSuccess?: (responseId: string) => void;
}

export const PublicQuestionnaireForm: React.FC<PublicQuestionnaireFormProps> = ({
  questionnaireId,
  questions,
  onSuccess
}) => {
  const [formData, setFormData] = useState<Record<string, any>>({});
  const [files, setFiles] = useState<Record<string, File[]>>({});
  const [submitting, setSubmitting] = useState(false);

  const handleInputChange = (questionId: string, value: any) => {
    setFormData(prev => ({ ...prev, [questionId]: value }));
  };

  const handleFileChange = (questionId: string, selectedFiles: FileList | null) => {
    if (selectedFiles) {
      setFiles(prev => ({ ...prev, [questionId]: Array.from(selectedFiles) }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      // הכנת נתוני התשובה
      const answers: Record<string, any> = {};
      const allFiles: File[] = [];

      questions.forEach(question => {
        const value = formData[question.id];
        if (value !== undefined) {
          answers[question.id] = value;
        }

        // איסוף קבצים
        if (question.type === 'file' && files[question.id]) {
          allFiles.push(...files[question.id]);
        }
      });

      // שליחה עם קבצים
      const responseId = await submitResponseWithFiles({
        questionnaire_id: questionnaireId,
        respondent_contact: {
          name: formData.name || '',
          email: formData.email || '',
          phone: formData.phone || ''
        },
        answers,
        files: allFiles,
        status: 'submitted'
      });

      toast({
        title: "תשובה נשלחה בהצלחה",
        description: "תודה על מילוי השאלון. נחזור אליך בקרוב.",
      });

      onSuccess?.(responseId);
    } catch (error) {
      console.error('Submission failed:', error);
      toast({
        title: "שליחה נכשלה",
        description: "אירעה שגיאה בשליחת התשובה. נסה שוב.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const renderQuestion = (question: any) => {
    const value = formData[question.id] || '';
    const questionFiles = files[question.id] || [];

    switch (question.type) {
      case 'short_text':
      case 'email':
      case 'phone':
        return (
          <input
            type={question.type === 'email' ? 'email' : question.type === 'phone' ? 'tel' : 'text'}
            value={value}
            onChange={(e) => handleInputChange(question.id, e.target.value)}
            required={question.required}
            className="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-teal-500 focus:ring-2 focus:ring-teal-200"
            placeholder={question.title}
          />
        );

      case 'long_text':
        return (
          <textarea
            value={value}
            onChange={(e) => handleInputChange(question.id, e.target.value)}
            required={question.required}
            className="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-teal-500 focus:ring-2 focus:ring-teal-200"
            placeholder={question.title}
            rows={4}
          />
        );

      case 'multiple_choice':
        return (
          <div className="space-y-2">
            {question.options?.map((option: string, index: number) => (
              <label key={index} className="flex items-center">
                <input
                  type="radio"
                  name={question.id}
                  value={option}
                  checked={value === option}
                  onChange={(e) => handleInputChange(question.id, e.target.value)}
                  className="mr-2"
                />
                {option}
              </label>
            ))}
          </div>
        );

      case 'checkbox':
        return (
          <div className="space-y-2">
            {question.options?.map((option: string, index: number) => (
              <label key={index} className="flex items-center">
                <input
                  type="checkbox"
                  value={option}
                  checked={Array.isArray(value) && value.includes(option)}
                  onChange={(e) => {
                    const currentValue = Array.isArray(value) ? value : [];
                    const newValue = e.target.checked
                      ? [...currentValue, option]
                      : currentValue.filter((v: string) => v !== option);
                    handleInputChange(question.id, newValue);
                  }}
                  className="mr-2"
                />
                {option}
              </label>
            ))}
          </div>
        );

      case 'file':
        return (
          <div className="space-y-2">
            <input
              type="file"
              multiple
              onChange={(e) => handleFileChange(question.id, e.target.files)}
              className="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-teal-500 focus:ring-2 focus:ring-teal-200"
            />
            {questionFiles.length > 0 && (
              <div className="text-sm text-gray-600">
                נבחרו {questionFiles.length} קבצים
              </div>
            )}
          </div>
        );

      case 'number':
        return (
          <input
            type="number"
            value={value}
            onChange={(e) => handleInputChange(question.id, e.target.value)}
            required={question.required}
            className="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-teal-500 focus:ring-2 focus:ring-teal-200"
            placeholder={question.title}
          />
        );

      case 'date':
        return (
          <input
            type="date"
            value={value}
            onChange={(e) => handleInputChange(question.id, e.target.value)}
            required={question.required}
            className="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-teal-500 focus:ring-2 focus:ring-teal-200"
          />
        );

      default:
        return null;
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {questions.map((question) => (
        <div key={question.id} className="space-y-2">
          <label className="block text-sm font-medium">
            {question.title}
            {question.required && <span className="text-red-500 ml-1">*</span>}
          </label>
          {renderQuestion(question)}
        </div>
      ))}

      <Button
        type="submit"
        disabled={submitting}
        className="w-full bg-teal-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-teal-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
      >
        {submitting ? "שולח..." : "שלח תשובה"}
      </Button>
    </form>
  );
};






