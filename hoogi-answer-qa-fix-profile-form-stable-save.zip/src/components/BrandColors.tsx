// BrandColors.tsx
import { HexColorPicker, HexColorInput } from "react-colorful";
import { useState, useMemo } from "react";

const HEX6 = /^#[0-9a-f]{6}$/;

function normalizeHex(input: string | undefined) {
  if (!input) return "";
  let s = input.trim().toLowerCase().replace(/^#?/, "");
  // תומך גם ב-#rgb → מרחיב ל-#rrggbb
  if (/^[0-9a-f]{3}$/.test(s)) s = s.split("").map(ch => ch + ch).join("");
  if (/^[0-9a-f]{6}$/.test(s)) return "#" + s;
  return ""; // לא תקין
}

function ColorField({
  label, value, onChange,
}: { label: string; value: string; onChange: (v: string) => void }) {
  const valid = HEX6.test(value);
  return (
    <div className="flex flex-col gap-2">
      <label className="font-medium">{label}</label>
      <div className="flex gap-4 items-start">
        <HexColorPicker color={value || "#000000"} onChange={(c) => onChange(normalizeHex(c) || value)} />
        <div className="flex flex-col gap-2 w-40">
          <HexColorInput
            color={value || ""}
            onChange={(c) => onChange(normalizeHex(c))}
            prefixed
            placeholder="#rrggbb"
            className={`border rounded px-2 py-1 ${valid ? "border-gray-300" : "border-red-400"}`}
          />
          <div className="h-8 rounded border" style={{ background: value || "#ffffff" }} />
          {!valid && <small className="text-red-500">הכניסי צבע בפורמט #rrggbb</small>}
        </div>
      </div>
    </div>
  );
}

export default function BrandColors({
  initial = { primary:"#1ea941", secondary:"#9bb365", accent:"#352b69" },
  onChange,
}: {
  initial?: { primary: string; secondary: string; accent: string };
  onChange: (v: { primary: string; secondary: string; accent: string; allValid: boolean }) => void;
}) {
  const [primary, setPrimary]     = useState(normalizeHex(initial.primary)   || "#1ea941");
  const [secondary, setSecondary] = useState(normalizeHex(initial.secondary) || "#9bb365");
  const [accent, setAccent]       = useState(normalizeHex(initial.accent)    || "#352b69");

  const allValid = useMemo(() => HEX6.test(primary) && HEX6.test(secondary) && HEX6.test(accent), [primary, secondary, accent]);

  // דווחי להורה בכל שינוי
  useMemo(() => onChange({ primary, secondary, accent, allValid }), [primary, secondary, accent, allValid, onChange]);

  return (
    <div className="grid md:grid-cols-3 gap-8">
      <ColorField label="צבע ראשי" value={primary}   onChange={setPrimary} />
      <ColorField label="צבע משני" value={secondary} onChange={setSecondary} />
      <ColorField label="צבע הדגשה" value={accent}   onChange={setAccent} />
    </div>
  );
}




