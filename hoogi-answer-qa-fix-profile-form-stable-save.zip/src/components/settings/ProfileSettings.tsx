import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { useLanguage } from '../../contexts/LanguageContext';
import ProfileForm from '../ProfileForm';

export const ProfileSettings: React.FC = () => {
  const { t } = useLanguage();

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t('settings.profileTitle')}</CardTitle>
        <CardDescription>
          {t('settings.profileSubtitle')}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ProfileForm 
          mode="edit"
          onSaved={(success) => {
            console.log("Profile saved in settings:", success);
          }}
        />
      </CardContent>
    </Card>
  );
};