import React, { useState } from 'react';
import { uploadFileToQuestionnaire, downloadFile } from '@/lib/uploadService';
import { Button } from './ui/button';
import { toast } from '@/hooks/use-toast';

interface FileUploadExampleProps {
  questionnaireId: string;
  onFileUploaded?: (path: string) => void;
}

export const FileUploadExample: React.FC<FileUploadExampleProps> = ({ 
  questionnaireId, 
  onFileUploaded 
}) => {
  const [uploading, setUploading] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<string[]>([]);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const path = await uploadFileToQuestionnaire(questionnaireId, file);
      setUploadedFiles(prev => [...prev, path]);
      onFileUploaded?.(path);
      toast({
        title: "העלאה הושלמה",
        description: `הקובץ ${file.name} הועלה בהצלחה`,
      });
    } catch (error) {
      console.error('Upload failed:', error);
      toast({
        title: "העלאה נכשלה",
        description: "אירעה שגיאה בהעלאת הקובץ",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  const handleDownload = async (path: string) => {
    try {
      await downloadFile(path);
    } catch (error) {
      console.error('Download failed:', error);
      toast({
        title: "הורדה נכשלה",
        description: "אירעה שגיאה בהורדת הקובץ",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium mb-2">
          העלאת קובץ
        </label>
        <input
          type="file"
          onChange={handleFileUpload}
          disabled={uploading}
          className="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-teal-500 focus:ring-2 focus:ring-teal-200"
        />
        {uploading && (
          <p className="mt-2 text-sm text-gray-600">מעלה קובץ...</p>
        )}
      </div>

      {uploadedFiles.length > 0 && (
        <div>
          <h4 className="text-sm font-medium mb-2">קבצים שהועלו:</h4>
          <div className="space-y-2">
            {uploadedFiles.map((path, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="text-sm text-gray-700 truncate">{path}</span>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleDownload(path)}
                >
                  הורד
                </Button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};






