import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Trash2, Plus, Upload, FileText, Link, ExternalLink } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { listSources, addLink as addLinkToDB, uploadPdf, removeSource, publicUrl, SourceKind } from '@/lib/sources';

interface Source {
  id: string;
  profile_id: string;
  user_id: string;
  kind: string;
  url?: string;
  file_path?: string;
  title?: string;
  created_at: string;
}

interface LinkSource {
  kind: SourceKind;
  url: string;
  title: string;
}

interface SourcesEditorProps {
  profileId: string;
  userId: string;
}

const LINK_TYPES: { value: SourceKind; label: string }[] = [
  { value: 'website', label: 'אתר' },
  { value: 'facebook', label: 'פייסבוק' },
  { value: 'instagram', label: 'אינסטגרם' },
  { value: 'linkedin', label: 'לינקדאין' },
  { value: 'youtube', label: 'יוטיוב' },
  { value: 'tiktok', label: 'טיקטוק' },
  { value: 'other', label: 'קישור אחר' },
];

export const SourcesEditor: React.FC<SourcesEditorProps> = ({ profileId, userId }) => {
  const [sources, setSources] = useState<Source[]>([]);
  const [links, setLinks] = useState<LinkSource[]>([]);
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);


  // Load sources on mount
  useEffect(() => {
    if (profileId) {
      loadSources();
    }
  }, [profileId]);

  const loadSources = async () => {
    try {
      setLoading(true);
      const data = await listSources();
      setSources(data);
    } catch (error) {
      console.error('Failed to load sources:', error);
      toast({
        title: 'שגיאה בטעינת מקורות',
        description: 'לא ניתן לטעון את רשימת המקורות',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const addLink = () => {
    setLinks([...links, { kind: 'website', url: '', title: '' }]);
  };

  const updateLink = (index: number, field: keyof LinkSource, value: string) => {
    const newLinks = [...links];
    newLinks[index] = { ...newLinks[index], [field]: value };
    setLinks(newLinks);
  };

  const removeLink = (index: number) => {
    setLinks(links.filter((_, i) => i !== index));
  };

  const onAddLink = async (link: LinkSource) => {
    try {
      setLoading(true);
      await addLinkToDB(link.kind, link.url, link.title);
      toast({ title: "קישור נשמר" });
      const rows = await listSources();
      setSources(rows);
      // Reset the link form
      setLinks(links.filter((_, i) => i !== links.length - 1));
    } catch (e: any) {
      console.error(e);
      toast({
        variant: "destructive",
        title: "שמירה נכשלה",
        description: e?.message || "אירעה שגיאה",
      });
    } finally {
      setLoading(false);
    }
  };

  const onUploadPdf = async (files: FileList | null) => {
    if (!files?.length) return;
    try {
      setUploading(true);
      for (const f of Array.from(files)) {
        await uploadPdf(f);
      }
      toast({ title: "קבצים הועלו" });
      const rows = await listSources();
      setSources(rows);
    } catch (e: any) {
      console.error(e);
      toast({
        variant: "destructive",
        title: "העלאה נכשלה",
        description: e?.message || "אירעה שגיאה",
      });
    } finally {
      setUploading(false);
    }
  };

  const onDeleteSource = async (id: string) => {
    try {
      await removeSource(id);
      const rows = await listSources();
      setSources(rows);
    } catch (e: any) {
      toast({
        variant: "destructive",
        title: "מחיקה נכשלה",
        description: e?.message || "אירעה שגיאה",
      });
    }
  };

  const getSourceIcon = (kind: string) => {
    switch (kind) {
      case 'pdf':
        return <FileText className="h-4 w-4" />;
      default:
        return <Link className="h-4 w-4" />;
    }
  };

  const getSourceLabel = (kind: string) => {
    const linkType = LINK_TYPES.find(t => t.value === kind);
    return linkType?.label || kind;
  };

  return (
    <div dir="rtl" className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Link className="h-5 w-5" />
            מקורות וקישורים
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Links Section */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">קישורים</h3>
              <Button onClick={addLink} size="sm">
                <Plus className="h-4 w-4 mr-2" />
                הוסף קישור
              </Button>
            </div>

            {links.map((link, index) => (
              <div key={index} className="flex gap-2 items-end">
                <div className="flex-1">
                  <label className="block text-sm font-medium mb-1">סוג קישור</label>
                  <Select
                    value={link.kind}
                    onValueChange={(value) => updateLink(index, 'kind', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {LINK_TYPES.map(type => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex-2">
                  <label className="block text-sm font-medium mb-1">כתובת URL</label>
                  <Input
                    value={link.url}
                    onChange={(e) => updateLink(index, 'url', e.target.value)}
                    placeholder="https://example.com"
                  />
                </div>
                
                <div className="flex-1">
                  <label className="block text-sm font-medium mb-1">כותרת (אופציונלי)</label>
                  <Input
                    value={link.title}
                    onChange={(e) => updateLink(index, 'title', e.target.value)}
                    placeholder="כותרת לקישור"
                  />
                </div>
                
                <div className="flex gap-1">
                  <Button
                    onClick={() => onAddLink(link)}
                    disabled={!link.url.trim()}
                    size="sm"
                  >
                    שמור
                  </Button>
                  <Button
                    onClick={() => removeLink(index)}
                    variant="outline"
                    size="sm"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>

          {/* PDF Upload Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">העלאת קבצי PDF</h3>
            
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
              <Upload className="h-8 w-8 mx-auto mb-2 text-gray-400" />
              <p className="text-sm text-gray-600 mb-2">גרור קבצי PDF לכאן או לחץ לבחירה</p>
              <input
                type="file"
                accept="application/pdf"
                multiple
                onChange={(e) => onUploadPdf(e.target.files)}
                disabled={uploading}
                className="hidden"
                id="pdf-upload"
              />
              <Button
                onClick={() => document.getElementById('pdf-upload')?.click()}
                disabled={uploading}
                variant="outline"
              >
                {uploading ? 'מעלה...' : 'בחר קבצים'}
              </Button>
            </div>
          </div>

          {/* Sources List */}
          {loading ? (
            <div className="text-center py-4">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-teal-600 mx-auto"></div>
              <p className="mt-2 text-sm text-gray-600">טוען מקורות...</p>
            </div>
          ) : sources.length > 0 ? (
            <div className="space-y-4">
              <h3 className="text-lg font-medium">מקורות קיימים</h3>
              <div className="space-y-2">
                {sources.map((source) => (
                  <div key={source.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      {getSourceIcon(source.kind)}
                      <div>
                        <p className="font-medium">{source.title || getSourceLabel(source.kind)}</p>
                        {source.url && (
                          <p className="text-sm text-gray-600">{source.url}</p>
                        )}
                        {source.file_path && (
                          <p className="text-sm text-gray-600">{source.file_path}</p>
                        )}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      {source.url && (
                        <Button
                          onClick={() => window.open(source.url, '_blank')}
                          variant="outline"
                          size="sm"
                        >
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                      )}
                      <Button
                        onClick={() => onDeleteSource(source.id)}
                        variant="outline"
                        size="sm"
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <Link className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p>אין מקורות עדיין</p>
              <p className="text-sm">הוסף קישורים או העלה קבצי PDF</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
