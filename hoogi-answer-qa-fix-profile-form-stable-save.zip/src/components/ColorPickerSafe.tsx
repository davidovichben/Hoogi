import { useState, useEffect } from 'react';
import { BRAND_PALETTES, HEX_OK } from '@/config/brandPalettes';

type Props = {
  label: string;
  value?: string | null;
  onChange: (hex: string | null, valid: boolean) => void;
};

export default function ColorPickerSafe({ label, value, onChange }: Props) {
  const [hex, setHex] = useState(value ?? '');
  const valid = !!hex && HEX_OK.test(hex.trim());

  useEffect(() => { setHex(value ?? ''); }, [value]);

  const pick = (v:string) => {
    setHex(v);
    onChange(v, HEX_OK.test(v));
  };

  return (
    <div className="space-y-2">
      <div className="text-sm font-medium">{label}</div>

      <div className="flex flex-wrap gap-2">
        {BRAND_PALETTES.map(p => (
          <button key={p.name} type="button"
            className="h-8 w-8 rounded border-2 border-gray-300 hover:border-gray-400 transition-colors"
            title={p.name}
            style={{ backgroundColor: p.primary }}
            onClick={() => pick(p.primary)}
          />
        ))}
      </div>

      <div className="flex items-center gap-2">
        <input type="color"
          value={HEX_OK.test(hex) ? hex : '#ffffff'}
          onChange={e => pick(e.target.value)}
          className="h-9 w-10 p-0 border rounded cursor-pointer"
        />
        <input type="text"
          className={`w-36 rounded-lg border px-3 py-2 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 ${hex && !valid ? 'border-red-500 bg-red-50' : 'border-gray-300'}`}
          placeholder="#RRGGBB"
          value={hex}
          onChange={e => {
            const v = e.target.value.trim();
            setHex(v);
            onChange(v || null, !!v && HEX_OK.test(v));
          }}
        />
        {hex && !valid && (
          <span className="text-xs text-red-600">פורמט לא תקין (#RRGGBB)</span>
        )}
      </div>
    </div>
  );
}
