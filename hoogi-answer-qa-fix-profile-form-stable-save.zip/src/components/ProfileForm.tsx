import React, { useEffect, useState, forwardRef, useImperativeHandle } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { fetchProfileByUserId, upsertProfile, getUserId } from "@/lib/rpc";
import { OCCUPATIONS } from "@/utils/occupations";
import { applyBrandingVars } from "@/lib/branding";
import { toast } from "@/hooks/use-toast";

// helper קטן, נשתמש בו כדי שתהיה הודעה גם אם אין ספריית toast מותקנת
const notify = {
  success: (m: string) => (toast?.success ? toast.success(m) : alert(m)),
  warning: (m: string) => (toast?.warning ? toast.warning(m) : alert(m)),
  error:   (m: string) => (toast?.error   ? toast.error(m)   : alert(m)),
};

// מחזיר #rrggbb תקין או null
function normalizeHex(input?: string | null): string | null {
  if (!input) return null;
  const s = String(input).trim();
  const m = s.match(/^#?[0-9A-Fa-f]{6}$/); // מאפשר גם עם וגם בלי #
  if (!m) return null;
  return ("#" + m[0].replace("#", "")).toLowerCase();
}
import BrandColors from "@/components/BrandColors";
import { SourcesEditor } from "@/components/profile/SourcesEditor";
import { routes } from "@/routes";
import { supabase } from "@/lib/supabaseClient";
import { sanitizeBrandColors, normalizeHex6 } from "@/utils/brandColors";
import { BRAND_DEFAULTS } from "@/constants/brand";

// --- HEX helper (local, to avoid undefined import) ---
type MaybeHex = string | null | undefined;
const normHex = (v: MaybeHex, fallback = "#ffffff"): string => {
  if (!v) return fallback;
  const s = String(v).trim();
  const m = s.match(/^#?([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/);
  if (!m) return fallback;
  let hex = m[1];
  if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
  return '#' + hex.toLowerCase();
};

// --- Brand defaults fallback (local) ---
const withDefaultHex = (value: string | null | undefined, fallback: string) => {
  if (!value) return fallback;
  const s = String(value).trim();
  const m = s.match(/^#?[0-9A-Fa-f]{6}$/);
  return m ? ('#' + m[0].replace('#','')).toLowerCase() : fallback;
};
// -----------------------------------------------------

export type ProfileFormHandle = { save: () => Promise<boolean>; isValid: () => boolean; };

type Props = { 
  mode?: "onboarding" | "edit"; 
  onSaved?: (ok: boolean) => void;
  onNext?: () => void;
  initialValues?: any;
};

const OTHER = "other";

// treat 'other' / 'אחר' as non-eligible for auto suggestions
const isOther = (v?: string | null) =>
  !v || ["other","אחר"].includes(String(v).trim().toLowerCase());

const ProfileForm = forwardRef<ProfileFormHandle, Props>(function ProfileForm({ 
  mode = "onboarding", 
  onSaved, 
  onNext,
  initialValues 
}, ref) {
  const navigate = useNavigate();
  const loc = useLocation();
  
  const [form, setForm] = useState({
    businessName: "",
    phone: "",
    email: "",
    website: "",
    locale: "he-IL",
    occupationChoice: "",
    suboccupationChoice: "",
    customOccupation: "",
    customSuboccupation: "",
    brandPrimary: BRAND_DEFAULTS.primary,
    brandSecondary: BRAND_DEFAULTS.secondary,
    backgroundColor: BRAND_DEFAULTS.background,
    brandLogoPath: "",
    // Color validation flags
    brandPrimaryValid: true,
    brandSecondaryValid: true,
    backgroundColorValid: true,
  });
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [lastSaveOk, setLastSaveOk] = useState(false);
  const [hasProfile, setHasProfile] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const [profileId, setProfileId] = useState<string | null>(null);
  const [isProfileComplete, setIsProfileComplete] = useState(false);

  // State עבור הצבעים החדשים
  const [brandColors, setBrandColors] = useState({
    primary: BRAND_DEFAULTS.primary,
    secondary: BRAND_DEFAULTS.secondary, 
    accent: BRAND_DEFAULTS.accent,
    allValid: true
  });

  // Load profile data
  useEffect(() => {
    let alive = true;
    
    const loadProfile = async () => {
      try {
        const currentUserId = await getUserId();
        if (!currentUserId) { 
          setLoading(false); 
          return; 
        }
        
        setUserId(currentUserId);
        
        const profile = await fetchProfileByUserId(currentUserId);
        if (!alive) return;
        
        if (!profile) { 
          setHasProfile(false);
          setProfileId(null);
          setIsProfileComplete(false);
          setLoading(false); 
          return; 
        }

        // Profile exists - mark as having a profile
        setHasProfile(!!profile.id);
        setProfileId(profile.id);
        setIsProfileComplete(!!profile.is_profile_complete);

        // Map DB values to form state
        const occKeys = Object.keys(OCCUPATIONS);
        let occupationChoice = profile.occupation ?? "";
        let suboccupationChoice = profile.suboccupation ?? "";
        let customOccupation = "";
        let customSuboccupation = "";

        // Handle "other" logic for occupation
        if (occupationChoice && !occKeys.includes(occupationChoice)) {
          customOccupation = occupationChoice;
          occupationChoice = OTHER;
          suboccupationChoice = "";
        }

        // Handle "other" logic for suboccupation
        if (occupationChoice && occupationChoice !== OTHER && suboccupationChoice) {
          const subList = OCCUPATIONS[occupationChoice] ?? [];
          if (!subList.includes(suboccupationChoice)) {
            customSuboccupation = suboccupationChoice;
            suboccupationChoice = OTHER;
          }
        }

        setForm(prev => ({
          ...prev,
          businessName: profile.business_name ?? "",
          phone: profile.phone ?? "",
          email: profile.email ?? "",
          website: profile.website ?? "",
          locale: profile.locale ?? "he-IL",
          occupationChoice,
          suboccupationChoice,
          customOccupation,
          customSuboccupation,
          brandPrimary: normHex(profile.brand_primary, "#000000"),
          brandSecondary: normHex(profile.brand_secondary, "#000000"),
          backgroundColor: normHex(profile.background_color, "#ffffff"),
          brandLogoPath: profile.brand_logo_path ?? "",
        }));

        // עדכון הצבעים החדשים
        setBrandColors({
          primary: withDefaultHex(profile.brand_primary, BRAND_DEFAULTS.primary),
          secondary: withDefaultHex(profile.brand_secondary, BRAND_DEFAULTS.secondary),
          accent: withDefaultHex(profile.brand_accent, BRAND_DEFAULTS.accent),
          allValid: true
        });

        // Apply branding
        applyBrandingVars({
          brand_primary: withDefaultHex(profile.brand_primary, BRAND_DEFAULTS.primary),
          brand_secondary: withDefaultHex(profile.brand_secondary, BRAND_DEFAULTS.secondary),
          background_color: withDefaultHex(profile.brand_accent, BRAND_DEFAULTS.accent),
        });

        // Check profile completion status from DB (if available)
        const phoneNorm = (profile.phone || '').replace(/[^0-9+]/g, '');
        const nameOk = !!(profile.full_name?.trim() || profile.business_name?.trim());
        const emailOk = !!(profile.email && /^[^\s@]+@[^\s@]+\\.[^\s@]+$/.test(profile.email));
        const occOk = !!profile.occupation?.trim();
        const subOccOk = !!profile.suboccupation?.trim();

        const completeStatus = nameOk && emailOk && phoneNorm.length >= 7 && occOk && subOccOk;
        setIsProfileComplete(completeStatus);

      } catch (error) {
        console.error("Failed to load profile:", error);
      } finally {
        setLoading(false);
      }
    };

    loadProfile();
    return () => { alive = false; };
  }, []);

  // Apply branding when colors change
  useEffect(() => {
    applyBrandingVars({
      brand_primary: withDefaultHex(brandColors.primary, BRAND_DEFAULTS.primary),
      brand_secondary: withDefaultHex(brandColors.secondary, BRAND_DEFAULTS.secondary),
      background_color: withDefaultHex(brandColors.accent, BRAND_DEFAULTS.accent),
    });
  }, [brandColors.primary, brandColors.secondary, brandColors.accent]);

  // Email validation helper
  const isEmail = (v: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v || "");

  // ולידציה לשדות חובה + מיפוי שם שדה → תווית בעברית
  const REQUIRED_FIELDS = ["business_name", "email", "phone", "industry"] as const;
  const FIELD_LABELS: Record<string, string> = {
    business_name: "שם העסק",
    email: "אימייל",
    phone: "נייד",
    industry: "תחום",
    sub_industry: "תת־תחום",
  };

  // Minimal profile validation - only required fields
  const isMinimalProfileValid = () => {
    const businessNameOk = (form.businessName?.trim() || "").length >= 2;
    const emailOk = isEmail(form.email);
    const phoneOk = (form.phone?.trim() || "").length > 0; // We'll normalize on save
    const industryOk = !!form.occupationChoice?.trim();
    
    // Validate "other" fields
    const occupationValid = form.occupationChoice !== OTHER || (form.customOccupation?.trim() || "").length > 0;
    const suboccupationValid = form.suboccupationChoice !== OTHER || (form.customSuboccupation?.trim() || "").length > 0;
    
    return businessNameOk && emailOk && phoneOk && industryOk && occupationValid && suboccupationValid;
  };

  // Form validation (legacy - keeping for compatibility)
  function isValidForm() {
    return isMinimalProfileValid();
  }

  // פונקציית שמירה שמבצעת רק עדכון (לא יצירה)
  async function saveProfile(values: any) {
    // בדיקת שדות חובה
    if (!values.business_name || !values.email || !values.phone) {
      toast({
        variant: 'destructive',
        title: 'לא נשמר',
        description: 'שם עסק, אימייל וטלפון הם שדות חובה',
      });
      return { ok: false as const };
    }

    // 1) מביאים את המשתמש והמזהה הקיים של הפרופיל
    const { data: auth } = await supabase.auth.getUser();
    const userId = auth?.user?.id;
    if (!userId) {
      notify.error("לא נשמר – אין משתמש מחובר.");
      return { ok: false as const };
    }

    let profileId = values.id as string | undefined;

    if (!profileId) {
      const { data: existing, error: qerr } = await supabase
        .from("profiles")
        .select("id")
        .eq("user_id", userId)
        .maybeSingle(); // יחזיר null אם אין

      if (qerr) {
        notify.error("לא נשמר – שגיאה בקריאת פרופיל קיים.");
        return { ok: false as const };
      }
      profileId = existing?.id;
    }

    if (!profileId) {
      notify.error("לא נשמר – לא נמצא פרופיל קיים למשתמש.");
      return { ok: false as const };
    }

    // נירמול טלפון דרך ה-RPC
    let phone_normalized: string | null = null;
    try {
      const { data: norm } = await supabase.rpc("normalize_phone", { _p: values.phone });
      phone_normalized = norm ?? null;
    } catch {
      phone_normalized = null;
    }

    // 2) בניית payload בסיסי
    const basePayload = {
      business_name: values.business_name?.trim() || undefined,
      email: values.email?.trim() || undefined,
      phone: values.phone?.trim() || undefined,
      phone_normalized,
      industry: values.industry || undefined,
      sub_industry: values.sub_industry || undefined,
      locale: values.locale || undefined,
      logo_url: values.logo_url || undefined,
      updated_at: new Date().toISOString(),
    };

    // נירמול צבעים + סינון לא חוקיים (לא יישלחו ל-DB)
    const colorPayload = sanitizeBrandColors({
      brand_primary: brandColors.primary,
      brand_secondary: brandColors.secondary,
      brand_accent: brandColors.accent, // יעבוד גם אם אין עמודה—פשוט לא ישלחו אותו
    });

    const payload = { ...basePayload, ...colorPayload };

    // 3) בדיקה אם יש שינוי לעומת ה-DB כדי למנוע UPDATE מיותר
    const { data: current } = await supabase
      .from("profiles")
      .select("business_name, email, phone, industry, sub_industry, locale, logo_url, brand_primary, brand_secondary, brand_accent")
      .eq("id", profileId)
      .maybeSingle();

    const changed = JSON.stringify(payload) !== JSON.stringify(
      Object.fromEntries(Object.entries(current ?? {}).filter(([,v]) => v !== null && v !== ""))
    );

    if (!changed) {
      notify.info("אין שינוי לשמירה");
      return { ok: true as const };
    }

    // 4) כתיבה: update ממוקד ולא upsert גורף
    try {
      const { error } = await supabase
        .from("profiles")
        .update(payload)
        .eq("id", profileId);

      if (error) throw error;
      
      toast({ title: 'נשמר בהצלחה', description: 'פרטי הפרופיל עודכנו.' });
      return { ok: true as const };
    } catch (e: any) {
      toast({
        variant: 'destructive',
        title: 'לא נשמר',
        description: e?.message ?? 'שגיאה בשמירת הפרופיל',
      });
      return { ok: false as const };
    }
  }

  // בדיקת שדות חובה
  function hasRequired(values: any) {
    return Boolean(
      values.business_name &&
      values.email &&
      values.phone &&
      values.industry &&
      brandColors.allValid
    );
  }

  // Save handler עם הפונקציה החדשה
  async function handleSave(): Promise<boolean> {
    setSaving(true);
    
    try {
      const values = {
        business_name: form.businessName,
        email: form.email,
        phone: form.phone,
        industry: form.occupationChoice === 'other' 
          ? form.customOccupation 
          : form.occupationChoice,
        sub_industry: form.suboccupationChoice === 'other' 
          ? form.customSuboccupation 
          : form.suboccupationChoice,
        locale: form.locale,
        brand_primary: form.brandPrimary,
        brand_secondary: form.brandSecondary,
        brand_accent: form.backgroundColor,
        logo_url: form.brandLogoPath,
      };

      // בדיקת שדות חובה לפני השמירה
      if (!hasRequired(values)) {
        notify.warning("לא נשמר – חסר אחד משדות החובה.");
        onSaved?.(false);
        return false;
      }

      const res = await saveProfile(values);
      
      if (res.ok) {
        // Update completion status
        const isComplete = isMinimalProfileValid();
        setIsProfileComplete(isComplete);
        setLastSaveOk(true);  // enables "Next"
        onSaved?.(true);

        // Handle navigation after successful save
        if (mode === "onboarding") {
          navigate('/onboarding?step=2');
        } else if (loc.search.includes('complete=1')) {
          navigate(routes.questionnaires);
        }
      } else {
        onSaved?.(false);
      }
      
      return res.ok;
    } catch (error: any) {
      console.error("Profile save error:", error);
      notify.error("אירעה שגיאה בשמירת הפרופיל");
      onSaved?.(false);
      return false;
    } finally {
      setSaving(false);
    }
  }

  // Handle Next button (onboarding mode)
  const handleNext = async () => {
    setSaving(true);
    try {
      const values = {
        business_name: form.businessName,
        email: form.email,
        phone: form.phone,
        industry: form.occupationChoice === 'other' 
          ? form.customOccupation 
          : form.occupationChoice,
        sub_industry: form.suboccupationChoice === 'other' 
          ? form.customSuboccupation 
          : form.suboccupationChoice,
        locale: form.locale,
        brand_primary: form.brandPrimary,
        brand_secondary: form.brandSecondary,
        brand_accent: form.backgroundColor,
        logo_url: form.brandLogoPath,
      };

      // בדיקת שדות חובה לפני השמירה
      if (!hasRequired(values)) {
        notify.warning("לא נשמר – חסר אחד משדות החובה.");
        return;
      }

      const res = await saveProfile(values);
      if (res.ok) {
        // עוברים לשלב השאלון (שם יש כפתור "שאלות מוצעות")
        navigate("/onboarding?step=2");
      }
      // אם לא ok – כבר קיבלת הודעה ברורה בעברית מהפונקציה
    } finally {
      setSaving(false);
    }
  };

  // Handle Back to Dashboard
  const handleBackToDashboard = () => {
    navigate("/dashboard");
  };

  useImperativeHandle(ref, () => ({ 
    save: handleSave, 
    isValid: () => isValidForm() 
  }));

  if (loading) {
    return (
      <div className="p-6 text-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-teal-600 mx-auto"></div>
        <p className="mt-2 text-gray-600">טוען...</p>
      </div>
    );
  }

  return (
    <div dir="rtl" className="space-y-6">
      {/* Profile completion status message */}
      {isProfileComplete && mode === "edit" && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
          <strong className="font-bold">✓ פרופיל מלא!</strong>
          <span className="block sm:inline"> כל הפרטים החשובים בפרופיל שלך מולאו בהצלחה.</span>
        </div>
      )}

      {/* Business Name */}
      <div>
        <label className="block text-sm font-medium mb-2">שם העסק *</label>
        <input 
          className="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-teal-500 focus:ring-2 focus:ring-teal-200"
          value={form.businessName}
          onChange={e => setForm(prev => ({ ...prev, businessName: e.target.value }))}
          placeholder="שם העסק"
        />
      </div>

      {/* Phone and Email */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-2">נייד *</label>
          <input 
            className="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-teal-500 focus:ring-2 focus:ring-teal-200"
            value={form.phone}
            onChange={e => setForm(prev => ({ ...prev, phone: e.target.value }))}
            placeholder="050-0000000"
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-2">מייל *</label>
          <input 
            className="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-teal-500 focus:ring-2 focus:ring-teal-200"
            value={form.email}
            onChange={e => setForm(prev => ({ ...prev, email: e.target.value }))}
            placeholder="you@example.com"
            type="email"
          />
        </div>
      </div>

      {/* Website and Locale */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-2">אתר</label>
          <input 
            className="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-teal-500 focus:ring-2 focus:ring-teal-200"
            value={form.website}
            onChange={e => setForm(prev => ({ ...prev, website: e.target.value }))}
            placeholder="https://..."
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-2">שפה</label>
          <input 
            className="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-teal-500 focus:ring-2 focus:ring-teal-200"
            value={form.locale}
            onChange={e => setForm(prev => ({ ...prev, locale: e.target.value }))}
            placeholder="he-IL"
          />
        </div>
      </div>

      {/* Occupation and Suboccupation */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-2">תחום *</label>
          <select 
            className="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-teal-500 focus:ring-2 focus:ring-teal-200"
            value={form.occupationChoice}
            onChange={e => setForm(prev => ({ 
              ...prev, 
              occupationChoice: e.target.value,
              suboccupationChoice: "",
              customSuboccupation: ""
            }))}
          >
            <option value="">בחר תחום</option>
            {Object.keys(OCCUPATIONS).map(key => (
              <option key={key} value={key}>{key}</option>
            ))}
            <option value={OTHER}>אחר</option>
          </select>
          
          {form.occupationChoice === OTHER && (
            <input 
              className="w-full rounded-lg border border-gray-300 px-4 py-3 mt-2 focus:border-teal-500 focus:ring-2 focus:ring-teal-200"
              placeholder="כתוב את התחום"
              value={form.customOccupation}
              onChange={e => setForm(prev => ({ ...prev, customOccupation: e.target.value }))}
            />
          )}
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">תת־תחום *</label>
          {form.occupationChoice && form.occupationChoice !== OTHER ? (
            <>
              <select 
                className="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-teal-500 focus:ring-2 focus:ring-teal-200"
                value={form.suboccupationChoice}
                onChange={e => setForm(prev => ({ ...prev, suboccupationChoice: e.target.value }))}
              >
                <option value="">בחר תת־תחום</option>
                {(OCCUPATIONS[form.occupationChoice] || []).map(sub => (
                  <option key={sub} value={sub}>{sub}</option>
                ))}
                <option value={OTHER}>אחר</option>
              </select>
              
              {form.suboccupationChoice === OTHER && (
                <input 
                  className="w-full rounded-lg border border-gray-300 px-4 py-3 mt-2 focus:border-teal-500 focus:ring-2 focus:ring-teal-200"
                  placeholder="כתוב תת־תחום"
                  value={form.customSuboccupation}
                  onChange={e => setForm(prev => ({ ...prev, customSuboccupation: e.target.value }))}
                />
              )}
            </>
          ) : (
            <input 
              className="w-full rounded-lg border border-gray-300 px-4 py-3 bg-gray-50"
              disabled 
              placeholder="בחר תחום קודם"
            />
          )}
        </div>
      </div>

      {/* Colors */}
      <BrandColors 
        initial={{
          primary: brandColors.primary,
          secondary: brandColors.secondary,
          accent: brandColors.accent
        }}
        onChange={setBrandColors}
      />

      {/* Logo Upload */}
      <div>
        <label className="block text-sm font-medium mb-2">לוגו</label>
        <div className="space-y-3">
          {/* Current Logo Display with Preview */}
          {form.brandLogoPath && (
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg border">
              <div className="flex-shrink-0">
                <img 
                  src={form.brandLogoPath} 
                  alt="תצוגה מקדימה של לוגו"
                  className="w-16 h-16 object-contain rounded border bg-white"
                  onError={(e) => {
                    // If image fails to load, show a placeholder
                    e.currentTarget.style.display = 'none';
                  }}
                />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">{form.brandLogoPath}</p>
                <p className="text-xs text-gray-500">לוגו נוכחי</p>
              </div>
              <button
                type="button"
                onClick={() => setForm(prev => ({ ...prev, brandLogoPath: "" }))}
                className="flex-shrink-0 text-red-600 hover:text-red-800 text-sm font-medium"
              >
                מחק
              </button>
            </div>
          )}
          
          {/* File Upload */}
          <input 
            type="file"
            accept="image/*"
            className="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:bg-teal-50 file:text-teal-700 hover:file:bg-teal-100"
            onChange={async (e) => {
              const file = e.target.files?.[0];
              if (file) {
                // Create a temporary URL for preview
                const tempUrl = URL.createObjectURL(file);
                // כאן נוסיף לוגיקה להעלאת הקובץ לשרת/storage
                // לעת עתה נשמור את ה-temporary URL
                setForm(prev => ({ ...prev, brandLogoPath: tempUrl }));
                toast({ title: "קובץ נבחר: " + file.name });
              }
            }}
          />
          
          {/* Manual URL Input (fallback) */}
          <div>
            <label className="block text-xs text-gray-500 mb-1">או הכנס URL ידנית:</label>
            <input 
              className="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-teal-500 focus:ring-2 focus:ring-teal-200"
              value={form.brandLogoPath}
              onChange={e => setForm(prev => ({ ...prev, brandLogoPath: e.target.value }))}
              placeholder="https://example.com/logo.png"
            />
          </div>
        </div>
      </div>

      {/* Sources Section */}
      {profileId && userId && (
        <SourcesEditor profileId={profileId} userId={userId} />
      )}

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-3 pt-6">
        {mode === "onboarding" ? (
          <>
            <button
              type="button"
              onClick={() => handleSave()}
              disabled={!isMinimalProfileValid() || !brandColors.allValid || saving}
              className="flex-1 bg-teal-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-teal-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {saving ? "שומר..." : "שמור"}
            </button>
            <button
              type="button"
              onClick={handleNext}
              disabled={!isMinimalProfileValid() && !lastSaveOk}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              הבא
            </button>
          </>
        ) : (
          <>
            <button
              type="button"
              onClick={() => handleSave()}
              disabled={!isMinimalProfileValid() || !brandColors.allValid || saving}
              className="flex-1 bg-teal-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-teal-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {saving ? "שומר..." : "שמור פרופיל"}
            </button>
            <button
              type="button"
              onClick={handleBackToDashboard}
              className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-colors"
            >
              חזרה לדשבורד
            </button>
          </>
        )}
      </div>
    </div>
  );
});

export default ProfileForm;
