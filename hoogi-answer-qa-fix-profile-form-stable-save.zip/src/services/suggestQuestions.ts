import { supabase } from "@/lib/supabaseClient";

type QuestionRow = {
  id: string;
  questionnaire_id: string;
  type: string;
  label: string;
  required: boolean;
  order_index: number;
  options: Record<string, any> | null;
  validation: Record<string, any> | null;
};

export async function generateSuggestedQuestions(questionnaireId: string) {
  const user = (await supabase.auth.getUser()).data.user;
  if (!user) throw new Error("not authenticated");

  const { data: profile } = await supabase
    .from("profiles")
    .select("business_name, industry, sub_industry, locale, brand_primary, brand_secondary, brand_accent, brand_logo_path")
    .eq("id", user.id)
    .maybeSingle();

  const { data: existingQs = [] } = await supabase
    .from("questions")
    .select("id, type, label, required, order_index, options")
    .eq("questionnaire_id", questionnaireId)
    .order("order_index", { ascending: true });

  const payload = {
    questionnaireId,
    profile: {
      business_name: profile?.business_name ?? null,
      industry: profile?.industry ?? null,
      sub_industry: profile?.sub_industry ?? null,
      locale: profile?.locale ?? "he",
      brand: {
        primary_color: profile?.brand_primary ?? null,
        secondary_color: profile?.brand_secondary ?? null,
        accent_color: profile?.brand_accent ?? null,
        logo_url: profile?.brand_logo_path ?? null,
      },
    },
    existing: existingQs.map(q => ({ type: q.type, label: q.label })),
    must_have_roles: ["name", "email", "phone"],
    allowed_types: ["text","email","number","select","radio","checkbox","date","file","textarea"],
    style_hint: "RTL, Hebrew if locale=he",
  };

  const { data, error } = await supabase.functions.invoke("suggest-questions", { body: payload });
  if (error) throw error;

  let suggestions: any[] = Array.isArray(data?.questions) ? data!.questions : [];

  // Fallback minimal set
  if (!suggestions.length) {
    suggestions = [
      { type: "text", label: "שם מלא", required: true, options: { role: "name" } },
      { type: "email", label: "אימייל", required: true, options: { role: "email" } },
      { type: "text", label: "טלפון", required: true, options: { role: "phone" } },
      { type: "textarea", label: "איך נוכל לעזור?", required: true },
    ];
  }

  // De-dup by normalized label
  const norm = (s:string) => (s||"").trim().toLowerCase().replace(/\s+/g," ");
  const existingSet = new Set(existingQs.map(q => norm(q.label)));
  const deduped = suggestions.filter(s => s?.label && !existingSet.has(norm(s.label)));

  // Ensure exactly one name/email/phone
  const want = new Map([["name", null],["email", null],["phone", null]]);
  for (const s of deduped) {
    const role = s?.options?.role;
    if (role && want.has(role) && !want.get(role)) want.set(role, s);
  }
  const ensureRole = (role:string, fallback:any) => want.get(role) || fallback;
  const withRoles = [
    ensureRole("name",  { type:"text",  label:"שם מלא", required:true, options:{role:"name"} }),
    ensureRole("email", { type:"email", label:"אימייל", required:true, options:{role:"email"} }),
    ensureRole("phone", { type:"text",  label:"טלפון", required:true, options:{role:"phone"} }),
    ...deduped.filter(s => !(s?.options?.role && ["name","email","phone"].includes(s.options.role))),
  ];

  // order_index
  const start = existingQs.length ? Math.max(...existingQs.map(q=>q.order_index||0)) + 1 : 0;
  const rows: QuestionRow[] = withRoles.slice(0, 25).map((s, i) => ({
    id: crypto.randomUUID(),
    questionnaire_id: questionnaireId,
    type: String(s.type),
    label: String(s.label),
    required: !!s.required,
    order_index: start + i,
    options: s.options ?? null,
    validation: s.validation ?? null,
  }));

  if (!rows.length) return;

  const { error: insErr } = await supabase.from("questions").insert(rows, { defaultToNull: false });
  if (insErr) throw insErr;
}
