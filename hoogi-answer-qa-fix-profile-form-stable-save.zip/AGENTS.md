# Hoogi Answer – Agents Guide
## Goals
- יציבות ניווט פרופיל → שאלון
- שאלון מותאם AI עם דה-דופ ושאלות קשר קבועות

## Do
- כבד את חוקי `.cursor/rules`
- השתמש בסקריפטים: sb-deploy, ai-health, ai-invoke, project-selfcheck
- קפד על JSON-only בקשר ל-Edge

## Don't
- לא לגעת בסכמה/DB בלי אישור
- לא להקשיח מפתחות בקוד
- לא לעצור זרימה ב-DEV על שגיאות קלות
