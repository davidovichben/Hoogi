$URL = 'https://lcazbaggfdejukjgkpeu.supabase.co/functions/v1/admin_gateway'
$TOKEN = 'd21bcca0-365e-4d7d-8f50-12805dbf6249511820d0b32f4936'
$headers = @{ 
    'Authorization' = "Bearer $TOKEN"
    'Content-Type' = 'application/json'
}

Write-Host "Testing GET endpoint..."
try {
    $response = Invoke-WebRequest -Uri $URL -Method GET -Headers $headers
    Write-Host "Status: $($response.StatusCode)"
    Write-Host "Response: $($response.Content)"
} catch {
    Write-Host "Error: $($_.Exception.Message)"
}

Write-Host "`nTesting RPC call for structure inventory..."
$body = '{"action":"rpc","rpc":"export_structure_inventory"}'
try {
    $response = Invoke-WebRequest -Uri $URL -Method POST -Headers $headers -Body $body -OutFile "structure_inventory.json"
    Write-Host "Status: $($response.StatusCode)"
    Write-Host "Structure inventory saved to structure_inventory.json"
} catch {
    Write-Host "Error: $($_.Exception.Message)"
}



