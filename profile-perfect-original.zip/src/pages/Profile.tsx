import ProfileForm from "@/components/ProfileForm";

export default function ProfilePage() {
  return <ProfileForm mode="manage" />;
}
